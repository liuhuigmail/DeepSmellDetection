package en.actions;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.internal.ui.packageview.PackageFragmentRootContainer;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.ISelectionService;
import org.eclipse.ui.IWorkbenchPartSite;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PlatformUI;

import en.actionsofproject.AddEntityPlacementIntoDB;
import en.actionsofproject.ProjectEvolution;
import gr.uom.java.ast.Standalone;


public class InlineMethodRefactorings implements IWorkbenchWindowActionDelegate {

	public static IWorkbenchPartSite workbenchpartSite;
	@Override
	public void run(IAction action) {	
		workbenchpartSite=PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActivePart().getSite();
		System.out.println("000000000000000000000000000000000000");
		multirun();
		// TODO Auto-generated method stub
	}
	
	private void multirun() {
		ISelectionService selectionService = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getSelectionService();    
		ISelection selection = selectionService.getSelection();
		if(selection instanceof IStructuredSelection) {
			for(int i=0;i<((IStructuredSelection)selection).size();i++) {
				IProject project = null; 
				Object element = ((IStructuredSelection)selection).toList().get(i);
				if (element instanceof IResource) {    
					project= ((IResource)element).getProject();    
				} else if (element instanceof PackageFragmentRootContainer) {    
					IJavaProject jProject =     
							((PackageFragmentRootContainer)element).getJavaProject();    
					project = jProject.getProject();    
				} else if (element instanceof IJavaElement) {    
					IJavaProject jProject= ((IJavaElement)element).getJavaProject();    
					project = jProject.getProject();    
				}
				System.out.println(project.getName());
				final IJavaProject selectedProject = JavaCore.create(project);
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				IProject selectedIProject = null;
				final Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
				for (IProject iProject : root.getProjects()) {
					if(iProject.getName().equals((selectedProject.getElementName()))){
						selectedIProject = iProject;
						break;
					}	
				}
				Runner runner=new Runner();
				runner.selectedIProject=selectedIProject;
				runner.selectedProject=selectedProject;
				runner.run();
				//Thread t=new Thread(runner,"runner"+i);
				//t.start();
				System.out.println(i);
			}
		}
	}
	
	public IProject getProject(){  
		IProject project = null;  
	//	IEditorPart part = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();  
		
		ISelectionService selectionService = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getSelectionService();    
		ISelection selection = selectionService.getSelection();
		if(selection instanceof IStructuredSelection) {    
			Object element = ((IStructuredSelection)selection).getFirstElement();
			if (element instanceof IResource) {    
				project= ((IResource)element).getProject();    
			} else if (element instanceof PackageFragmentRootContainer) {    
				IJavaProject jProject =     
						((PackageFragmentRootContainer)element).getJavaProject();    
				project = jProject.getProject();    
			} else if (element instanceof IJavaElement) {    
				IJavaProject jProject= ((IJavaElement)element).getJavaProject();    
				project = jProject.getProject();    
			}  
		}     
		
		return project;  
	} 

	@Override
	public void selectionChanged(IAction arg0, ISelection arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public void init(IWorkbenchWindow arg0) {
		// TODO Auto-generated method stub

	}

}

class Runner implements Runnable{
	public IJavaProject selectedProject;
	public IProject selectedIProject;
	

	
	public Runner() {
		selectedProject=null;
		selectedIProject=null;

	}
	
	public void run() {
		System.out.println("IProject's  name----"+selectedIProject.getName());
		ProjectEvolution projectEvolution = new ProjectEvolution(selectedProject, selectedIProject);
		long start=System.currentTimeMillis();
		projectEvolution.run();
		long end=System.currentTimeMillis();
		System.out.println("#########################======================"+(end-start));
	}
}
