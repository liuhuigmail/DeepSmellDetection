package en.movemethod;

public class RefactorMoveMethod {

}
