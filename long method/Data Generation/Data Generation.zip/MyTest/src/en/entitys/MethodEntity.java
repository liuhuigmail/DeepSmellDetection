package en.entitys;

import org.eclipse.jdt.core.IJavaElement;

public class MethodEntity extends Entity {

	public MethodEntity(IJavaElement element) {
		super(element);
		// TODO Auto-generated constructor stub
	}

}
