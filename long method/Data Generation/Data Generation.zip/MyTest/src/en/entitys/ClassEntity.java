package en.entitys;

public class ClassEntity {

}
