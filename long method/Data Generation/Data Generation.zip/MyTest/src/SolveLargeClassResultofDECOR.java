import java.sql.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;

public class SolveLargeClassResultofDECOR {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		String code="";
//		double v=getMetrics(code);
//		int keynum=1;
//		
//		Map map=new HashMap();
//		
//		map.put(keynum, new Double[] {new Double(v),new Double(0.0)});
//		map.put(2, new Double[] {new Double(56),new Double(0.0)});
//		map.put(3, new Double[] {new Double(10),new Double(0.0)});
//		map.put(4, new Double[] {new Double(100),new Double(0.0)});
//		
//		BoxPlot boxPlot = new BoxPlot(map, 0.0);
//		
//		Map res = boxPlot.getHighOutliers();
//		System.out.println(v);
//		System.out.println(boxPlot.getMaxBound());
//		System.out.println(res.get(1));
		String[] ps= {"android-backup-extractor-20140630","AoI30","areca-7.4.7","freeplane-1.3.12",
				"grinder-3.6","jedit","jexcelapi_2_6_12","junit-4.10","pmd-5.2.0","weka"};
		for(int i=0;i<ps.length;i++) {
			System.out.println("--------------------------------------");
			System.out.println(ps[i]);
			solve(ps[i]);
		}
	}
	
	private static void solve(String projectname) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection conn = DriverManager.getConnection(
	                "jdbc:mysql://127.0.0.1:3306/mydata?serverTimezone=GMT",
	                "root","12345");
			
			PreparedStatement ps1=conn.prepareStatement("select * from largeclassinformations_train where projectname=?");
			PreparedStatement ps2=conn.prepareStatement("insert into decor_largeclass_statistic values(?,?,?,?,?,?)");
			ps1.setString(1, projectname);
			ResultSet rs=ps1.executeQuery();
			
			Map allclass=new HashMap();
			Map temp=new HashMap();
			
			while(rs.next()) {
				Info info=new Info();
				info.keynum=rs.getInt("keynum");
				info.classname=rs.getString("classname");
				info.code=rs.getString("code");
				info.label=rs.getDouble("Label");
				info.dlabel=0;
				info.value=getMetrics(info.code);
				allclass.put(info.keynum, info);
				temp.put(info.keynum, new Double[] {new Double(info.value),new Double(0.0)});
			}
			ps1.close();
			
			BoxPlot boxPlot = new BoxPlot(temp, 0.0);
			Map res=boxPlot.getHighOutliers();
			System.out.println(res.size()+"  "+boxPlot.getMaxBound());
			Iterator ite=allclass.values().iterator();
			
			while(ite.hasNext()) {
				Info info=(Info)(ite.next());
				if(res.get(info.keynum)!=null) info.dlabel=1;
				
				ps2.setInt(1, info.keynum);
				ps2.setString(2, projectname);
				ps2.setString(3, info.classname);
				ps2.setDouble(4, info.value);
				ps2.setDouble(5, info.dlabel);
				ps2.setDouble(6, info.label);
				ps2.execute();
			}
			ps2.close();
			conn.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private static double getMetrics(String code) {
		ASTParser parser=ASTParser.newParser(AST.JLS3);
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
		parser.setSource(code.toCharArray());
		CompilationUnit cu = (CompilationUnit) parser.createAST(null);
		MyVisitor visitor=new MyVisitor();
		cu.accept(visitor);
		return visitor.NMD+visitor.NAD;
	}

}

class MyVisitor extends ASTVisitor{
	public double NMD,NAD;
	
	public MyVisitor() {
		NMD=0;
		NAD=0;
	}
	
	public boolean visit(FieldDeclaration node) {
		NAD+=node.fragments().size();
		return true;
	}
	
	public boolean visit(MethodDeclaration node) {
		NMD++;
		return true;
	}
}
