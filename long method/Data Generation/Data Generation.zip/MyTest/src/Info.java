
public class Info {
	public int keynum;
	public String classname;
	public String code;
	public double dlabel;
	public double label;
	public double value;
	
}
