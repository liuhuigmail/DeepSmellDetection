package gdata.generate;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;

public class TEMP {
	public void run(IJavaProject jp) throws JavaModelException {
		int noc=0,nom=0,loc=0;
		for(IPackageFragment pf : jp.getPackageFragments()) {
			for(ICompilationUnit icu : pf.getCompilationUnits()) {
				String code=icu.getSource();
				for(int i=0;i<code.length();i++) if(code.charAt(i)=='\n')
					loc++;
				for(IType type : icu.getTypes()) {
					noc++;
					for(IMethod m : type.getMethods()) {
						nom++;
					}
				}
			}
		}
		System.out.println(noc+"  "+nom+"  "+loc);
	}
}
