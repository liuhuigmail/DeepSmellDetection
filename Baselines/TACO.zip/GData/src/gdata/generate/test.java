package gdata.generate;

import com.mysql.jdbc.StringUtils;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String t="//	public void generateTACO() {\r\n" + 
				"//		try {\r\n" + 
				"//			Class.forName(\"com.mysql.jdbc.Driver\");\r\n" + 
				"//			Connection conn=DriverManager.getConnection(\"jdbc:mysql://localhost:3306/misplaceclass\", \"root\", \"123456\");\r\n" + 
				"//			PreparedStatement ps=conn.prepareStatement(\"insert into relations values(?,?,?)\");\r\n" + 
				"//			\r\n" + 
				"//			for(IPackageFragment pf : SampleHandler.jproject.getPackageFragments()) if(pf.getCompilationUnits().length>0){\r\n" + 
				"//				String txt=\"\";\r\n" + 
				"//				for(ICompilationUnit icu : pf.getCompilationUnits()) {\r\n" + 
				"//					IType type=icu.getType(icu.getElementName().split(\"\\\\.\")[0]);\r\n" + 
				"//					String code=\r\n" + 
				"//					\r\n" + 
				"//				}\r\n" + 
				"//			}\r\n" + 
				"//		}catch(Exception e) {\r\n" + 
				"//			e.printStackTrace();\r\n" + 
				"//		}\r\n" + 
				"//	}\r\n" + 
				"	\r\n" + 
				"//	public String solve(String code) {\r\n" + 
				"//		\r\n" + 
				"//	}\r\n" + 
				"	\r\n" + 
				"/*jin jia hao*/" +
				"	public void run() {\r\n" + 
				"		//getRelations();\r\n" + 
				"		//generateTrainSet();\r\n" + 
				"		//generateTestSet();\r\n" + 
				"		//generateCaseStudy();\r\n" + 
				"		\r\n" + 
				"	}";
		//System.out.println(solve(t));
		String a="a.b";
		System.out.println(a.split("\\.")[0]);
	}
	public static String solve(String code) {
		String keys="abstract|assert|boolean|break|case|catch|class|const|continue|default|do|else|enum|extends|false|final|finally|for|goto|if|implements|import|instanceof|interface|native|new|null|package|private|protected|public|return|short|static|strictfp|super|switch|synchronized|this|throw|throws|true|transient|try|void|volatile|while";
		String temp=code.replaceAll("//|/\\*|\\*/", "").replaceAll(keys, "").replaceAll("\n","").replaceAll("\r","").replaceAll("\n\r","").replaceAll("\t","");
		String res="";
		for(int i=0;i<temp.length();i++) { 
			char c=temp.charAt(i);
			if(Character.isLowerCase(c))
				res+=c;
			else if(Character.isUpperCase(c))
				res+=" "+Character.toLowerCase(c);
			else if(Character.isDigit(c))
				res+=" "+c+" ";
			else if(c=='_')
				res+=" ";
			else
				res+=" ";
		}
		res=res.replaceAll("\\s{1,}", " ");
		PorterStemmer s=new PorterStemmer();
		String[] words=res.split(" ");
		res="";
		for(int i=0;i<words.length;i++) {
			s.add(words[i].toCharArray(),words[i].length());
			s.stem();
			res+=s.toString()+" ";
		}
		
		return res;
	}
}
