package gdata.generate;

import java.util.ArrayList;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SimpleType;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;

public class MyVisitorCBO extends ASTVisitor{
	
	ArrayList<ICompilationUnit> related_icus;

	
	public MyVisitorCBO(String typename) {
		related_icus=new ArrayList<ICompilationUnit>();

	}
	
	@Override
	public boolean visit(FieldDeclaration node) {
		if(node.getType() instanceof SimpleType) {
			SimpleType v=(SimpleType)node.getType();
			if(v.resolveBinding()==null) return true;
			//System.out.println(v.getName()+"--"+v.resolveBinding().getQualifiedName()+"  "+v.resolveBinding().getPackage().getName());
			//IPackageFragment pf=(IPackageFragment)(v.resolveBinding().getPackage().getJavaElement());
			if((v.resolveBinding().getJavaElement().getParent()) instanceof ICompilationUnit) {
				ICompilationUnit icu=(ICompilationUnit)(v.resolveBinding().getJavaElement().getParent());
				related_icus.add(icu);
				
			}
		}
		return true;
	}

	@Override
	public boolean visit(MethodDeclaration node) {
		for(Object p : node.parameters()) {
			SingleVariableDeclaration v=(SingleVariableDeclaration)p;
			
			if(v.getType() instanceof SimpleType) {
				SimpleType vv=(SimpleType)v.getType();
				if(vv.resolveBinding()==null) return true;
				if((vv.resolveBinding().getJavaElement().getParent()) instanceof ICompilationUnit) {
					ICompilationUnit icu=(ICompilationUnit)(vv.resolveBinding().getJavaElement().getParent());
					related_icus.add(icu);
				}
			}
		}
		if(node.getReturnType2() instanceof SimpleType) {
			SimpleType vv=(SimpleType)(node.getReturnType2());
			if(vv.resolveBinding()==null) return true;
			if((vv.resolveBinding().getJavaElement().getParent()) instanceof ICompilationUnit) {
				ICompilationUnit icu=(ICompilationUnit)(vv.resolveBinding().getJavaElement().getParent());
				related_icus.add(icu);
			}
		}
		return true;
	}
	
	@Override
	public boolean visit(VariableDeclarationStatement node) {
		if(node.getType() instanceof SimpleType) {
			SimpleType v=(SimpleType)(node.getType());
			if(v.resolveBinding()==null) return true;
			//System.out.println(v.resolveBinding().getQualifiedName()+"  "+v.resolveBinding().getPackage().getName());
			//IPackageFragment pf=(IPackageFragment)(v.resolveBinding().getPackage().getJavaElement());
			if((v.resolveBinding().getJavaElement().getParent()) instanceof ICompilationUnit) {
				ICompilationUnit icu=(ICompilationUnit)(v.resolveBinding().getJavaElement().getParent());
				related_icus.add(icu);
			}
		}
		return true;
	}
	
	@Override
	public boolean visit(MethodInvocation node) {
		//System.out.println(node.resolveMethodBinding().getDeclaringClass().getQualifiedName());
		if(node.resolveMethodBinding()==null) return true;
		ITypeBinding type=node.resolveMethodBinding().getDeclaringClass();
		if(type==null||type.getPackage()==null) return true;
		//IPackageFragment pf=(IPackageFragment)(type.getPackage().getJavaElement());
		if((type.getJavaElement().getParent()) instanceof ICompilationUnit) {
			ICompilationUnit icu=(ICompilationUnit)(type.getJavaElement().getParent());
			related_icus.add(icu);

		}

		return true;
	}

}