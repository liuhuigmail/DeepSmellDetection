package gdata.generate;

import static org.junit.Assert.assertNotNull;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.internal.corext.refactoring.reorg.IReorgDestination;
import org.eclipse.jdt.internal.corext.refactoring.reorg.IReorgPolicy.IMovePolicy;
import org.eclipse.jdt.internal.corext.refactoring.reorg.JavaMoveProcessor;
import org.eclipse.jdt.internal.corext.refactoring.reorg.ReorgDestinationFactory;
import org.eclipse.jdt.internal.corext.refactoring.reorg.ReorgPolicyFactory;
import org.eclipse.jdt.internal.corext.refactoring.reorg.ReorgUtils;
import org.eclipse.jdt.internal.ui.refactoring.RefactoringMessages;
import org.eclipse.jdt.internal.ui.refactoring.actions.RefactoringStarter;
import org.eclipse.jdt.internal.ui.refactoring.reorg.CreateTargetQueries;
import org.eclipse.jdt.internal.ui.refactoring.reorg.ReorgMoveAction;
import org.eclipse.jdt.internal.ui.refactoring.reorg.ReorgMoveWizard;
import org.eclipse.jdt.internal.ui.refactoring.reorg.ReorgQueries;
import org.eclipse.jdt.ui.wizards.JavaCapabilityConfigurationPage;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.IWizardContainer;
import org.eclipse.jdt.internal.corext.refactoring.reorg.IReorgDestination;
import org.eclipse.ltk.core.refactoring.CheckConditionsOperation;
import org.eclipse.ltk.core.refactoring.PerformRefactoringOperation;
import org.eclipse.ltk.core.refactoring.Refactoring;
import org.eclipse.ltk.core.refactoring.RefactoringContext;
import org.eclipse.ltk.core.refactoring.RefactoringStatus;
import org.eclipse.ltk.core.refactoring.participants.MoveRefactoring;
import org.eclipse.ltk.ui.refactoring.RefactoringUI;
import org.eclipse.ltk.ui.refactoring.RefactoringWizard;
import org.eclipse.ltk.ui.refactoring.RefactoringWizardOpenOperation;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPartSite;
import org.eclipse.ui.PlatformUI;

import gdata.handlers.SampleHandler;
import gr.uom.java.ast.ASTReader;
import gr.uom.java.ast.CompilationErrorDetectedException;
import taco.tacovisitor;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;


public class Runner {

	ArrayList<IPackageFragment> pfs;
	ArrayList<ICompilationUnit> icus;
	ArrayList<IType> types;
	Shell shell;
	boolean flag;
	HashMap<String,String> m1;
	//List<IType> types = new ArrayList<IType>();
	
	public Runner() {
		pfs=new ArrayList<IPackageFragment>();
		icus=new ArrayList<ICompilationUnit>();
		types=new ArrayList<IType>();
		m1=new HashMap<String,String>();
	}
	
	public void init() throws JavaModelException, SQLException {
		if(pfs!=null) pfs.clear();
		if(icus!=null) icus.clear();
		if(types!=null) types.clear();
		if(m1!=null) m1.clear();
		shell=PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActivePart().getSite().getShell();
		flag=false;
		//DBOperation db=new DBOperation();
		for(IPackageFragment pf : SampleHandler.jproject.getPackageFragments()) if(pf.getCompilationUnits().length>0){
			if(pf.getCompilationUnits().length>0)
				pfs.add(pf);
			String t="";
			for(ICompilationUnit icu : pf.getCompilationUnits()) {
				IType type=icu.getType(icu.getElementName().split("\\.")[0]);
				t+=icu.getSource();
				icus.add(icu);
				types.add(type);
				//db.insertClassInfo(SampleHandler.jproject.getElementName(), pf.getElementName(), type.getFullyQualifiedName());
			}
			if(t!="")
				m1.put(pf.getElementName(), t);
		}
		System.out.println("Init Done!!");
	}
	
	public void getRelations() {
		try {
			init();
			int size=icus.size();
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/misplaceclass", "root", "123456");
			PreparedStatement ps=conn.prepareStatement("insert into relations values(?,?,?)");
			ps.setString(1, SampleHandler.jproject.getElementName());
			Random r=new Random();
			int total=0;

			for(int i=0;i<size;i++) {
//				if(flag) {
//					System.out.println("Bingo2");
//
//					break;
//				}
				
				long start=System.currentTimeMillis();
				ICompilationUnit icu=icus.get(i);
				ps.setString(2, types.get(i).getFullyQualifiedName());
				
				IPackageFragment pf=pfs.get(r.nextInt(pfs.size()));
				if(haveSameNameType(pf,icu.getElementName())) continue;
				System.out.println(pf.getElementName()+"  "+icu.getElementName()+"  Moving...");
				if(moveclass(pf,icu)) {
					ps.setString(3, pf.getElementName());
					//ps.execute();
					total++;
				}
				long end=System.currentTimeMillis();
				System.out.println(""+(i+1)+" / "+icus.size()+"  already "+total+"  Time : "+(end-start)/1000);
			}
			ps.close();
			conn.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void generateTrainSet() {
		try {
			//init();
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/misplaceclass", "root", "123456");
			PreparedStatement ps1=conn.prepareStatement("select * from relations where classname=?");
			PreparedStatement ps2=conn.prepareStatement("insert into input values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
			System.out.println("Data Building...");
			MetricsCalculator cal=new MetricsCalculator(pfs,icus,types);
			System.out.println("CBO Matrix Done!!!");
			
			
			for(int i=0;i<icus.size();i++) {
				ps1.setString(1, types.get(i).getFullyQualifiedName());
				ResultSet relation=ps1.executeQuery();
				while(relation.next()) {
					ICompilationUnit icu=icus.get(i);
					IType type=types.get(i);
					//////////////////////////////////////////////////////////////
					//if(!type.getElementName().equals("WritableImage")) break;
					
					IPackageFragment ori_pf=(IPackageFragment)(icu.getParent());
					IPackageFragment tar_pf=null;
					for(int j=0;j<pfs.size();j++) if(pfs.get(j).getElementName().equals(relation.getString("packagename"))) {
						tar_pf=pfs.get(j);
						break;
					}
					if(tar_pf==null) break;
					
					
					Map<ICompilationUnit,Integer> orimpc=cal.calculateMPC(icu,ori_pf);
					Map<ICompilationUnit,Integer> tarmpc=cal.calculateMPC(icu,tar_pf);
					
					double ori_mpc_max=getMax(orimpc);
					double ori_mpc_cnt=getCnt(orimpc);
					double ori_mpc_ave=ori_mpc_cnt/ori_pf.getCompilationUnits().length;
					double tar_mpc_max=getMax(tarmpc);
					double tar_mpc_cnt=getCnt(tarmpc);
					double tar_mpc_ave=tar_mpc_cnt/tar_pf.getCompilationUnits().length;
					
					double ori_cbo=cal.calculateCBO(icu, ori_pf);
					double tar_cbo=cal.calculateCBO(icu, tar_pf);
					System.out.println(ori_cbo);
					ps2.setString(1, SampleHandler.jproject.getElementName());
					ps2.setString(2, ori_pf.getElementName());
					ps2.setString(3, type.getFullyQualifiedName());
					ps2.setString(4, type.getElementName());
					ps2.setString(5, ori_pf.getElementName());
					ps2.setString(6, tar_pf.getElementName());
					
					ps2.setDouble(7, ori_cbo);
					ps2.setDouble(8, ori_mpc_max);
					ps2.setDouble(9, ori_mpc_ave);
					ps2.setDouble(10, ori_mpc_cnt);
					ps2.setDouble(11, tar_cbo);
					ps2.setDouble(12, tar_mpc_max);
					ps2.setDouble(13, tar_mpc_ave);
					ps2.setDouble(14, tar_mpc_cnt);
					ps2.setDouble(15, 0);
					
					//ps2.execute();

					ps2.setString(5, tar_pf.getElementName());
					ps2.setString(6, ori_pf.getElementName());
					
					ps2.setDouble(7, tar_cbo);
					ps2.setDouble(8, tar_mpc_max);
					ps2.setDouble(9, tar_mpc_ave);
					ps2.setDouble(10, tar_mpc_cnt);
					ps2.setDouble(11, ori_cbo);
					ps2.setDouble(12, ori_mpc_max);
					ps2.setDouble(13, ori_mpc_ave);
					ps2.setDouble(14, ori_mpc_cnt);
					ps2.setDouble(15, 1);
					
					//ps2.execute();
				}
				System.out.println((i+1)+" / "+icus.size());
			}
			ps1.close();
			ps2.close();
			conn.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void generateCaseStudy() {
		try {
			init();
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/misplaceclass", "root", "123456");
			PreparedStatement ps=conn.prepareStatement("insert into case_study values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			MetricsCalculator cal=new MetricsCalculator(pfs,icus,types);
			
			IPackageFragment temp_pf=null;
			for(IPackageFragment pf : SampleHandler.jproject.getPackageFragments()){
				if(pf.getElementName().equals("jinpf")) {
					temp_pf=pf;
					break;
				}
			}
			icus.clear();
			types.clear();
			for(IPackageFragment pf : SampleHandler.jproject.getPackageFragments()){
				for(ICompilationUnit icu : pf.getCompilationUnits()) {
					if(moveclass(temp_pf,icu)) {
						IType type=icu.getType(icu.getElementName().split("\\.")[0]);
						icus.add(icu);
						types.add(type);
					}
				}
			}
			
			
			for(int i=0;i<icus.size();i++) {
				ICompilationUnit icu=icus.get(i);
				IType type=types.get(i);
				IPackageFragment ori_pf=(IPackageFragment)(icu.getParent());
				for(int j=0;j<pfs.size();j++) {
					IPackageFragment tar_pf=pfs.get(j);
					if(tar_pf.getElementName().equals(ori_pf.getElementName()))
						continue;
					Map<ICompilationUnit,Integer> orimpc=cal.calculateMPC(icu,ori_pf);
					Map<ICompilationUnit,Integer> tarmpc=cal.calculateMPC(icu,tar_pf);
					
					double ori_mpc_max=getMax(orimpc);
					double ori_mpc_cnt=getCnt(orimpc);
					double ori_mpc_ave=ori_mpc_cnt/ori_pf.getCompilationUnits().length;
					double tar_mpc_max=getMax(tarmpc);
					double tar_mpc_cnt=getCnt(tarmpc);
					double tar_mpc_ave=tar_mpc_cnt/tar_pf.getCompilationUnits().length;
					
					double ori_cbo=cal.calculateCBO(icu, ori_pf);
					double tar_cbo=cal.calculateCBO(icu, tar_pf);
					//System.out.println(ori_cbo);
					
					if(ori_mpc_max+ori_mpc_cnt+ori_mpc_ave+tar_mpc_max+tar_mpc_cnt+tar_mpc_cnt+tar_mpc_ave+ori_cbo==0) {
						Random tr=new Random();
						if(tr.nextInt(10)!=3)
							continue;
					}
					
					ps.setString(1, SampleHandler.jproject.getElementName());
					ps.setString(2, ori_pf.getElementName());
					ps.setString(3, type.getFullyQualifiedName());
					ps.setString(4, type.getElementName());
					ps.setString(5, ori_pf.getElementName());
					ps.setString(6, tar_pf.getElementName());
					
					ps.setDouble(7, ori_cbo);
					ps.setDouble(8, ori_mpc_max);
					ps.setDouble(9, ori_mpc_ave);
					ps.setDouble(10, ori_mpc_cnt);
					ps.setDouble(11, tar_cbo);
					ps.setDouble(12, tar_mpc_max);
					ps.setDouble(13, tar_mpc_ave);
					ps.setDouble(14, tar_mpc_cnt);
					//System.out.println(type==null);

					
					//ps.execute();
				}
				System.out.println((i+1)+" / "+icus.size());
			}
			ps.close();
			conn.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void generateTestSet() {
		try {
			init();
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/misplaceclass", "root", "123456");
			PreparedStatement ps1=conn.prepareStatement("select * from relations where classname=?");
			PreparedStatement ps2=conn.prepareStatement("insert into test_items values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			PreparedStatement ps3=conn.prepareStatement("insert into test_class values(?,?,?)");
			
			
			
			System.out.println("Data Building...");
			MetricsCalculator cal=new MetricsCalculator(pfs,icus,types);
			System.out.println("CBO Matrix Done!!!");
			
			Random r=new Random();
			
			
			for(int i=0;i<icus.size();i++) {
				ps1.setString(1, types.get(i).getFullyQualifiedName());
				ResultSet relation=ps1.executeQuery();
				while(relation.next()) {
					ICompilationUnit icu=icus.get(i);
					IType type=types.get(i);
					
					IPackageFragment ori_pf=(IPackageFragment)(icu.getParent());
					
					
					if(r.nextInt(10000)>1959) {
						Map<ICompilationUnit,Integer> orimpc=cal.calculateMPC(icu,ori_pf);
						double ori_mpc_max=getMax(orimpc);
						double ori_mpc_cnt=getCnt(orimpc);
						double ori_mpc_ave=ori_mpc_cnt/ori_pf.getCompilationUnits().length;
						double ori_cbo=cal.calculateCBO(icu, ori_pf);
						
						ps2.setString(1, SampleHandler.jproject.getElementName());
						ps2.setString(2, ori_pf.getElementName());
						ps2.setString(3, type.getFullyQualifiedName());
						ps2.setString(4, type.getElementName());
						
						IPackageFragment tar_pf=pfs.get(r.nextInt(pfs.size()));
						if(haveSameNameType(tar_pf,icu.getElementName())) continue;
						Map<ICompilationUnit,Integer> tarmpc=cal.calculateMPC(icu,tar_pf);					
						double tar_mpc_max=getMax(tarmpc);
						double tar_mpc_cnt=getCnt(tarmpc);
						double tar_mpc_ave=tar_mpc_cnt/tar_pf.getCompilationUnits().length;
						double tar_cbo=cal.calculateCBO(icu, tar_pf);
						ps2.setString(5, ori_pf.getElementName());
						ps2.setString(6, tar_pf.getElementName());
						ps2.setDouble(7, ori_cbo);
						ps2.setDouble(8, ori_mpc_max);
						ps2.setDouble(9, ori_mpc_ave);
						ps2.setDouble(10, ori_mpc_cnt);
						ps2.setDouble(11, tar_cbo);
						ps2.setDouble(12, tar_mpc_max);
						ps2.setDouble(13, tar_mpc_ave);
						ps2.setDouble(14, tar_mpc_cnt);
						
						ps2.execute();
						
						ps3.setString(1, type.getFullyQualifiedName());
						ps3.setDouble(2, 0);
						ps3.setString(3, "NULL");
						ps3.execute();
						continue;
					}
					
					
					
					IPackageFragment tpf=null;
					while(true) {
						tpf=pfs.get(r.nextInt(pfs.size()));
						if(!(tpf.getElementName().equals(ori_pf.getElementName())))
							break;
					}
					
					Map<ICompilationUnit,Integer> orimpc=cal.calculateMPC(icu,tpf);
					double ori_mpc_max=getMax(orimpc);
					double ori_mpc_cnt=getCnt(orimpc);
					double ori_mpc_ave=ori_mpc_cnt/tpf.getCompilationUnits().length;
					double ori_cbo=cal.calculateCBO(icu, tpf);
					
					ps2.setString(1, SampleHandler.jproject.getElementName());
					ps2.setString(2, tpf.getElementName());
					ps2.setString(3, type.getFullyQualifiedName());
					ps2.setString(4, type.getElementName());
					
					for(IPackageFragment tar_pf : pfs) if(!(tar_pf.getElementName().equals(tpf.getElementName()))) {
						Map<ICompilationUnit,Integer> tarmpc=cal.calculateMPC(icu,tar_pf);				
						double tar_mpc_max=getMax(tarmpc);
						double tar_mpc_cnt=getCnt(tarmpc);
						double tar_mpc_ave=tar_mpc_cnt/tar_pf.getCompilationUnits().length;
						double tar_cbo=cal.calculateCBO(icu, tar_pf);

						ps2.setString(5, tpf.getElementName());
						ps2.setString(6, tar_pf.getElementName());
						ps2.setDouble(7, ori_cbo);
						ps2.setDouble(8, ori_mpc_max);
						ps2.setDouble(9, ori_mpc_ave);
						ps2.setDouble(10, ori_mpc_cnt);
						ps2.setDouble(11, tar_cbo);
						ps2.setDouble(12, tar_mpc_max);
						ps2.setDouble(13, tar_mpc_ave);
						ps2.setDouble(14, tar_mpc_cnt);
						
						ps2.execute();
	
					}
					ps3.setString(1, type.getFullyQualifiedName());
					ps3.setDouble(2, 1);
					ps3.setString(3, ori_pf.getElementName());
					ps3.execute();
				}
				System.out.println((i+1)+" / "+icus.size());
			}
			ps1.close();
			ps2.close();
			ps3.close();
			conn.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void generateTACO() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/misplaceclass", "root", "123456");
			//PreparedStatement ps=conn.prepareStatement("insert into TACO_class values(?,?,?,?)");
			PreparedStatement ps=conn.prepareStatement("insert into taco_temp values(?,?,?,?)");
			PreparedStatement ps1=conn.prepareStatement("insert into TACO_package values(?,?,?)");

			ps.setString(1, SampleHandler.jproject.getElementName());
			ps1.setString(1, SampleHandler.jproject.getElementName());
			for(IPackageFragment pf : SampleHandler.jproject.getPackageFragments()) if(pf.getCompilationUnits().length>0){
				System.out.println(pf.getElementName());
				ps.setString(2, pf.getElementName());
				ps1.setString(2, pf.getElementName());
				String txt="";
				for(ICompilationUnit icu : pf.getCompilationUnits()) {
					IType type=icu.getType(icu.getElementName().split("\\.")[0]);

					String code=null;
					String classname=null;
					try {
						code=type.getSource();
						classname=type.getFullyQualifiedName();
					}
					catch(Exception e) {
						code="";
						classname=pf.getElementName()+"."+icu.getElementName().split("\\.")[0];
					}
					code=solve(code);
					txt+=code+" ";
					ps.setString(3, classname);
					ps.setString(4, code);
					//ps.execute();
				}
//				ps1.setString(3, txt);
//				ps1.execute();

			}

			ps.close();
			ps1.close();
			conn.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void calDependence() {
		try {
			init();
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/misplaceclass", "root", "123456");
			PreparedStatement ps1=conn.prepareStatement("insert into taco_relate values(?,?,?,?)");
			ps1.setString(1, SampleHandler.jproject.getElementName());
			int ith=1;
			for(IType type : types) {
				ps1.setString(2, type.getParent().getParent().getElementName());
				ps1.setString(3, type.getFullyQualifiedName());
				for(IPackageFragment pf : pfs) {
					
					String t=m1.get(pf.getElementName());
					if(t.contains(type.getFullyQualifiedName())) {
						ps1.setString(4, pf.getElementName());
						ps1.execute();
					}
				}
				System.out.println((ith++)+" / "+types.size());
			}
			ps1.close();
			conn.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void generateTestProject() {
		try {
			init();
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/misplaceclass", "root", "123456");
			PreparedStatement ps1=conn.prepareStatement("select * from test_class where qualifiedclassname=?");
			PreparedStatement ps2=conn.prepareStatement("select * from test_items where classqualifiedname=?");
			int cnt=0;
			for(int i=0;i<icus.size();i++) {
				ICompilationUnit icu=icus.get(i);
				IType type=types.get(i);
				ps1.setString(1, type.getFullyQualifiedName());
				ResultSet rs1=ps1.executeQuery();
				while(rs1.next()) {
					if(rs1.getDouble("label")==0)
						break;
					ps2.setString(1, type.getFullyQualifiedName());
					ResultSet rs2=ps2.executeQuery();
					while(rs2.next()) {
						String pn=rs2.getString("packagename");
						for(IPackageFragment pf : pfs) if(pf.getElementName().equals(pn)) {
							if(moveclass(pf,icu)) {
								System.out.println("Move");
								cnt++;
							}
							break;
						}
						break;
					}
					break;
				}
				System.out.println((i+1)+" / "+icus.size());
			}
			System.out.println(cnt);
			ps1.close();
			ps2.close();
			conn.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void calculate() {
		try {
			int cn=0;
			int mn=0;
			int loc=0;
			for(IPackageFragment pf : SampleHandler.jproject.getPackageFragments()){
				for(ICompilationUnit icu : pf.getCompilationUnits()) {
					for(IType type : icu.getTypes()) {
						cn++;
						for(IMethod method : type.getMethods()) {
							mn++;
						}
						String code=type.getSource();
						loc++;
						for(int i=0;i<code.length();i++) if(code.charAt(i)=='\n')
							loc++;
					}
				}
			}
			System.out.println(cn+" "+mn+" "+loc);
		}catch(Exception e) {
			
		}
	}
	
	public long run() {
		long ss=System.currentTimeMillis();
		//getRelations();
		//generateTrainSet();
		//generateTestSet();
		//generateCaseStudy();
		
		//generateTestProject();
		generateTACO();
		calDependence();
		//calculate();
		return (System.currentTimeMillis()-ss);
	}
	
	
	
	public String solve(String code) {
		String keys="abstract|assert|boolean|break|case|catch|class|const|continue|default|do|else|enum|extends|false|final|finally|for|goto|if|implements|import|instanceof|interface|native|new|null|package|private|protected|public|return|short|static|strictfp|super|switch|synchronized|this|throw|throws|true|transient|try|void|volatile|while";
		String temp=code.replaceAll("//|/\\*|\\*/", "").replaceAll(keys, "").replaceAll("\n","").replaceAll("\r","").replaceAll("\n\r","").replaceAll("\t","");
		String res="";
		for(int i=0;i<temp.length();i++) { 
			char c=temp.charAt(i);
			if(Character.isLowerCase(c))
				res+=c;
			else if(Character.isUpperCase(c))
				res+=" "+Character.toLowerCase(c);
			else if(Character.isDigit(c))
				res+=" "+c+" ";
			else if(c=='_')
				res+=" ";
			else
				res+=" ";
		}
		res=res.replaceAll("\\s{1,}", " ");
		PorterStemmer s=new PorterStemmer();
		String[] words=res.split(" ");
		res="";
		for(int i=0;i<words.length;i++) {
			s.add(words[i].toCharArray(),words[i].length());
			s.stem();
			res+=s.toString()+" ";
		}
		
		return res;
	}
	
	
	public boolean moveclass(IPackageFragment pf,ICompilationUnit clazz) throws InterruptedException, CoreException {

		IMovePolicy policy= ReorgPolicyFactory.createMovePolicy(new IResource[0],new IJavaElement[]{clazz});
		if (policy.canEnable()) {
			JavaMoveProcessor processor=new JavaMoveProcessor(policy);
			IReorgDestination destination=ReorgDestinationFactory.createDestination(pf);
			RefactoringStatus status=processor.setDestination(destination);
			if (status.hasError()) {
				return false;
			}
			processor.setUpdateReferences(true);	
			processor.setReorgQueries(new ReorgQueries(shell));
			ReorgQueries rq=new ReorgQueries(shell);
			MoveRefactoring refactoring = new MoveRefactoring(processor);
			IProgressMonitor pm = new NullProgressMonitor();
			
			try {
				refactoring.checkInitialConditions(pm);
				refactoring.checkFinalConditions(pm);
				final PerformRefactoringOperation op = new PerformRefactoringOperation(refactoring, CheckConditionsOperation.ALL_CONDITIONS);
				op.run(new NullProgressMonitor());

//				try {
//					new ASTReader(SampleHandler.jproject, null);
//				}catch(CompilationErrorDetectedException e) {
//					System.out.println("CompilationErrorDetectedException");
//					//op.getUndoChange().perform(new NullProgressMonitor());
//					return false;
//				}

				op.getUndoChange().perform(new NullProgressMonitor());

				return true;

				
				
			}catch (Exception e) {
				flag=true;
				return false;
			}
		}
		return false;
	}
	
	public boolean haveSameNameType(IPackageFragment pf,String name) throws JavaModelException {
		for(ICompilationUnit icu : pf.getCompilationUnits()) if(icu.getElementName().equals(name))
			return true;
		return false;
	}
	
	public IResource[] getResources(IJavaElement element) {
		if(element instanceof IResource) return new IResource[] {(IResource)element};
		return new IResource[0];
	}
	
	public double getMax(Map<ICompilationUnit,Integer> res) {
		double max=0;

		Iterator ite=res.values().iterator();
		while(ite.hasNext()) {
			int v=((Integer)(ite.next())).intValue();
			if(v>max) max=v;
		}

		return max;
	}
	
	public double getCnt(Map<ICompilationUnit,Integer> res) {
		double cnt=0;


		Iterator ite=res.values().iterator();
		while(ite.hasNext()) {
			int v=((Integer)(ite.next())).intValue();
			cnt+=v;
		}

		return cnt;
	}
	
}
