package gdata.generate;

import java.sql.*;

public class DBOperation {
	Connection conn;
	public DBOperation() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/misplaceclass", "root", "123456");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void insertClassInfo(String projectname,String packagename,String classname) throws SQLException {
		PreparedStatement ps1 = conn.prepareStatement("insert into classinfo values(?,?,?)");
		ps1.setString(1, projectname);
		ps1.setString(2, packagename);
		ps1.setString(3, classname);
		ps1.execute();
		ps1.close();
	}
	
	public void insertRelations(String projectname,String classname,String packagename) throws SQLException {
		PreparedStatement ps = conn.prepareStatement("insert into relations values(?,?,?)");
		ps.setString(1, projectname);
		ps.setString(2,classname);
		ps.setString(3, packagename);
		ps.execute();
		ps.close();
	}
	
	public void insertInput(String projectname,String packagename,String classqualifiedname,String classname,String ori_package,String tar_package,double ori_cbo, double ori_mpc_max,double ori_mpc_ave,double ori_mpc_sum,double tar_cbo, double tar_mpc_max,double tar_mpc_ave,double tar_mpc_sum,double label) {
		try {
			PreparedStatement ps2 = conn.prepareStatement("insert into input values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps2.setString(1, projectname);
			ps2.setString(2, packagename);
			ps2.setString(3, classqualifiedname);
			ps2.setString(4, classname);
			ps2.setString(5, ori_package);
			ps2.setString(6, tar_package);
			
			ps2.setDouble(7, ori_cbo);
	
			ps2.setDouble(8, ori_mpc_max);
			ps2.setDouble(9, ori_mpc_ave);
			ps2.setDouble(10, ori_mpc_sum);
			
			ps2.setDouble(11, tar_cbo);
			ps2.setDouble(12, tar_mpc_max);
			ps2.setDouble(13, tar_mpc_ave);
			ps2.setDouble(14, tar_mpc_sum);
			
			ps2.setDouble(15, label);
			
			ps2.execute();
			ps2.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void close() throws SQLException {
		conn.close();
	}
}
