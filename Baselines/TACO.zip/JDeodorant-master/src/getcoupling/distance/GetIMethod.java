package getcoupling.distance;

public class GetIMethod {
	
	String str1;
	String str2;
	

}
