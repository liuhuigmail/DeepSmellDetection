package gr.uom.java.jdeodorant.refactoring.mytest.actions.movemethod;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.EnumConstantDeclaration;
import org.eclipse.jdt.core.dom.EnumDeclaration;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.IVariableBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.internal.ui.packageview.PackageFragmentRootContainer;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.ISelectionService;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.progress.IProgressService;

import gr.uom.java.ast.ASTReader;
import gr.uom.java.ast.ClassObject;
import gr.uom.java.ast.CompilationErrorDetectedException;
import gr.uom.java.ast.CompilationUnitCache;
import gr.uom.java.ast.Standalone;
import gr.uom.java.ast.SystemObject;
import gr.uom.java.distance.CandidateRefactoring;
import gr.uom.java.distance.DistanceMatrix;
import gr.uom.java.distance.MoveMethodCandidateRefactoring;
import gr.uom.java.distance.MySystem;
import gr.uom.java.jdeodorant.refactoring.Activator;
import gr.uom.java.jdeodorant.refactoring.mytest.actions.ActionsAboutUndo;
import gr.uom.java.jdeodorant.refactoring.mytest.actions.CreateTargetField;
import gr.uom.java.jdeodorant.refactoring.mytest.actions.JudgeMethodWhetherMove;


public class RelatedClass {
	
	private static final String MESSAGE_DIALOG_TITLE = "Feature Envy";
	//List<IMethod> allMethods = new ArrayList<IMethod>(); //the iJavaproject's all allMethods
	IProject iProject;
	IJavaProject iJavaProject;
	public Map<IMethod, Integer> methodStatus = new HashMap();//whether method has moved  yes:1 no: 0
	public List<ITypeBinding> typeBindingCanMove = new ArrayList<>();//the classes can be moved
	public TypeDeclaration typeDeclarationOfCurrentClass;
	public ITypeBinding currentClass;
	public IMethod currentIMethod;
	Map<IMethod, IVariableBinding> methodAndTarget = new HashMap();//method and it's one target
	Map<IMethod, MethodDeclaration> methodAndItsMethodDeclaration =new HashMap();//
	List<IMethod> allMethodsCanBeMoved = new ArrayList<IMethod>();
	List<IMethod> allStaticMethodCanBeMoved = new ArrayList<IMethod>();
	public List<MoveMethodNode> refactorNodes = new ArrayList<>();//�м��������ƶ�����Ŀ�ĵ��࣬���м����ڵ�
	public List<IVariableBinding> IVarbindsCanMove = new ArrayList<>();
	Map<IMethod,String> methodNameAndItsTargetName = new HashMap();
	List<String> methodNamesComparedToJDeodorant = new ArrayList<String>();
	List<String> classNamesComparedToJDeodorant = new ArrayList<String>();
	Map<String,String> methodNameAndClassName = new HashMap();
	
	
	public RelatedClass(IProject iProject,IJavaProject iJavaProject){
		init();
		this.iProject = iProject;
		this.iJavaProject = iJavaProject;
	}
	
	@SuppressWarnings("restriction")
	public void getMoveMethodCandidates(IType type) throws CoreException{
		init();
		IMethodCollection iMethodCollection = new IMethodCollection();
		MethodEntity methodEntity = new MethodEntity(type);
		typeDeclarationOfCurrentClass = methodEntity.getTypeDeclaration();
		currentClass = typeDeclarationOfCurrentClass.resolveBinding();
		MethodDeclaration[] methodDeclarations = typeDeclarationOfCurrentClass.getMethods();
		JudgeMethodWhetherMove judgeMethodWhetherMove = new JudgeMethodWhetherMove(type);
		List<IMethod> getterOrSettermethods = iMethodCollection.collectAccessors(type); 
		List<IMethod> accessors = selectMethods(methodEntity.getMethods(), methodDeclarations, judgeMethodWhetherMove, getterOrSettermethods);
		System.out.println("clasaPath---------------------------------------------------------"
				+ "------------------------------------------"+typeDeclarationOfCurrentClass.resolveBinding().getQualifiedName());
		for(IMethod method : accessors){
			MethodEntity methodEntity1 = new MethodEntity(method);
			MethodDeclaration methodDeclaration = (MethodDeclaration) methodEntity1.getAssociatedNode();
			methodAndItsMethodDeclaration.put(method, methodDeclaration);
			
			IVarbindsCanMove.clear();
			calVarbingdsCanMove(methodDeclaration, method);
						
			currentIMethod = method;
			VisitorForMethod vis = new VisitorForMethod();
			typeDeclarationOfCurrentClass.accept(vis);
//			for(ITypeBinding tBCanMove : typeBindingCanMove){
//				System.out.println("typeBindingCanMove-----------------"+tBCanMove.getName());
//			}
		}
		for(int i=0; i < refactorNodes.size(); i++){
			IVariableBinding vb = refactorNodes.get(i).variableBindings.get(0);
			IMethod method = refactorNodes.get(i).method;
			if(!methodAndTarget.containsKey(method)){
				
				MethodEntity entity1 = new MethodEntity(method);
				CompilationUnit unit = entity1.getUnit();
				TypeDeclaration typeDeclaration = entity1.getTypeDeclaration();
				MethodDeclaration[] allMethodDeclaration = typeDeclaration.getMethods();
				MethodDeclaration methodDeclaration = methodAndItsMethodDeclaration.get(method);
				for(MethodDeclaration methodDeclarationx : allMethodDeclaration){
					if(methodDeclarationx.equals(methodDeclaration)){
						methodDeclaration = methodDeclarationx;
					}
						
				}
				if((methodDeclaration.getModifiers()& Modifier.STATIC) != 0){
					allStaticMethodCanBeMoved.add(method);
				}
				else{
					allMethodsCanBeMoved.add(method);
				}
				methodNameAndItsTargetName.put(method, refactorNodes.get(i).typeBinding.getQualifiedName());
				if(vb == null){
					ITypeBinding targetTypeBinding = refactorNodes.get(i).typeBinding;
					IVariableBinding targetBinding = CreateTargetField.startCreateTarget(unit, typeDeclaration, methodDeclaration, targetTypeBinding);
					methodAndTarget.put(method, targetBinding);
				}
				else
					methodAndTarget.put(method, vb);
			}	
		}
		System.out.println("all Method Can Be moved's size------------------  "+allMethodsCanBeMoved.size());
		//readTxtFile();
		refactoringsExcute(allMethodsCanBeMoved,methodAndTarget);
		
		//IMethod[] allMethods = new IMethod[accessors.size()];
		//accessors.toArray(allMethods);
	}
	public void init(){
		IVarbindsCanMove.clear();
		refactorNodes.clear();
		typeBindingCanMove.clear();
		methodAndTarget.clear();
		allMethodsCanBeMoved.clear();
	}
	
	public List<IMethod> selectMethods(List<IMethod> allMethods, MethodDeclaration[] methodDeclarations, JudgeMethodWhetherMove judgeMethodWhetherMove, List<IMethod> getterOrSettermethods){
		List<IMethod> methodCanBeMoved = new ArrayList<IMethod>();
		int length = (int) (allMethods.size()*0.1);
		int flag = 0;
		
		for(IMethod method : allMethods){
			for(MethodDeclaration methodDeclaration : methodDeclarations){
				if((methodDeclaration.getName().toString().equals(method.getElementName())) && (method.getDeclaringType().getFullyQualifiedName().toString().equals(methodDeclaration.resolveBinding().getDeclaringClass().getQualifiedName().toString()))){
					if(judgeMethodWhetherMove.methodCanMove(method, methodDeclaration)){
						if(!getterOrSettermethods.contains(method) && !methodCanBeMoved.contains(method)){
							methodCanBeMoved.add(method);
							methodAndItsMethodDeclaration.put(method, methodDeclaration);
							//methodDeclaration.resolveBinding().getDeclaringClass().getQualifiedName();
							//System.out.println(methodDeclaration.resolveBinding().getName()+"---methodCanBeMoved$$$$$$$$$-----------");
							break;
							
						}
					}	
				}
			}
		}
		return methodCanBeMoved;
	}
	@SuppressWarnings({ "unchecked"})
	public void calVarbingdsCanMove(MethodDeclaration method, IMethod currentIMethod){//find all destinations
		
		List<SingleVariableDeclaration> parameters = (List<SingleVariableDeclaration>)method.parameters();
		if(parameters == null || parameters.size() == 0){
			return;
		}
		List<IVariableBinding> targets = new ArrayList<>();
		boolean canMove = false;
		for(Iterator<SingleVariableDeclaration> it = parameters.iterator(); it.hasNext(); ){
			IVariableBinding bind = it.next().resolveBinding();
			
			if(bind.getType().isFromSource() && !bind.getType().equals(currentClass)){
				targets.add(bind);
				if(!typeBindingCanMove.contains(bind.getType()))
					typeBindingCanMove.add(bind.getType());
				canMove = true;
				boolean visited = false;
				for(MoveMethodNode node : refactorNodes){
					if(node.typeBinding.equals(bind.getType())){
						visited = true;
						node.variableBindings.add(0,bind);
						break;
					}
				}
				if(visited == false){ 
					MoveMethodNode node2 = new MoveMethodNode();
					node2.typeBinding = bind.getType();
					List<IVariableBinding> vars = new ArrayList<>();
					vars.add(bind);
					node2.variableBindings = vars;
					node2.method = currentIMethod;
					node2.targetTypeName = bind.getName();
					refactorNodes.add(node2);
				}
			}
		}
		if(canMove == false)
			return;
		IVarbindsCanMove.addAll(targets);
		
	}
	int MoveAndIsFE = 0;//TP
	int NoMoveAndIsFE = 0;//FP
	int numOfMoveMethod = 0;
	int targetClassCorrect = 0;
	int noMoveMethod = 0;
	//int sumOfRe = 0;
	private Runtime run = Runtime.getRuntime();
	@SuppressWarnings("static-access")
	protected void refactoringsExcute(List<IMethod> allMethods, Map<IMethod, IVariableBinding> methodAndTarget) throws CoreException {
		
		 ActionsAboutUndo undoActions = new ActionsAboutUndo();
		
		 //System.out.println("currentClass----"+currentClass.getQualifiedName());
		 for(int i = 0; i < allMethods.size(); i++){
			 IMethod method = allMethods.get(i);
			 String sourceClassName = method.getDeclaringType().getFullyQualifiedName();
			 int random=(int)(Math.random()*2);
			 System.out.println("the method is moving ================================================================"+method.getElementName());
			 System.out.println("targetClass=========================================================================="+methodNameAndItsTargetName.get(allMethods.get(i)));
			 //getTable();
			 int state = 0;
			 run.gc();
			 MoveMethodActions moveMethodActions = new MoveMethodActions();
			 try {
				 moveMethodActions.moveMethod(allMethods.get(i), methodAndTarget.get(allMethods.get(i)));

			 } catch (NullPointerException | CoreException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			 }
			 
			 
			// iProject.build(IncrementalProjectBuilder.CLEAN_BUILD, null);
			 //iProject.refreshLocal(IResource.DEPTH_INFINITE, null);
			CompilationUnitCache.getInstance().clearCache();
			
			try {
				new ASTReader(iJavaProject, null);
			} catch (CompilationErrorDetectedException e) {
				// TODO Auto-generated catch block
				System.out.println("----CompilationErrorDetectedException");
				undoActions.undo();
				continue;
			}
			if(random == 1){//move method
				state = 1;
				numOfMoveMethod++;
			 }
			else{//no move method
				undoActions.undo();
				noMoveMethod++;
			 }
			try {
				new ASTReader(iJavaProject, null);
			} catch (CompilationErrorDetectedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			writeToTxtFile(method,sourceClassName,state);
			getTable(method,iJavaProject,state);
			
			System.out.println("start undo-----");
			undoActions.undo();
			
			run.gc();
			System.out.println("free memory---"+run.freeMemory());
			System.out.println("total memory---"+run.totalMemory());
		 }
		 System.out.println("TargeClassCorrect------------"+targetClassCorrect);
		 System.out.println("MoveAndIsFE--------"+MoveAndIsFE);
		 System.out.println("NoMoveAndIsFE--------"+NoMoveAndIsFE);
		 System.out.println("numOfMoveMethod---------"+numOfMoveMethod);
		 System.out.println("noMoveMethod------------"+noMoveMethod+"\n\n");
	}

	public void writeToTxtFile(IMethod method,String SourceClassName, int label){
	    
	    try {
	    	String parameters = methodParameters(methodAndItsMethodDeclaration.get(method));
	        String content = method.getElementName() +' '+parameters+' '+ SourceClassName+' '+methodNameAndItsTargetName.get(method)+' '+label;
	        File file = new File("D:\\Word2Vec\\data\\compareWithJDeodorant\\file\\MoveMethodNameAndState_"+iProject.getName()+".txt");
	        if(!file.exists())
	        	file.createNewFile(); 
	        
            FileWriter fw = new FileWriter(file,true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(content);
            bw.write('\n');
            bw.close();
            fw.close();
            System.out.println("MoveMethodNameAndState done!");
	         
	    } catch (Exception e) {
	        // TODO: handle exception
	    }
	}
	public void readTxtFile(){
		File file = new File("D:\\Word2Vec\\data\\compareWithJDeodorant\\file\\MoveMethodNameAndState_"+iProject.getName()+".txt");
		StringBuilder result = new StringBuilder();
        try{
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String s = null;
            while((s = reader.readLine())!=null){//ʹ��readLine������һ�ζ�һ��
      
            	String[] splitString = s.split(" ");
            	String methodName1= splitString[0];
            	String className1 = splitString[1];
            	methodNameAndClassName.put(methodName1, className1);
            	methodNamesComparedToJDeodorant.add(methodName1);
            	classNamesComparedToJDeodorant.add(className1);
            }
            reader.close();    
        }catch(Exception e){
            e.printStackTrace();
        }
       
	}
	private void getTable(IMethod method,final IJavaProject iJavaProject, int state) {
		try {
			IWorkbench wb = PlatformUI.getWorkbench();
			IProgressService ps = wb.getProgressService();

			SystemObject systemObject = ASTReader.getSystemObject();
			if(systemObject != null) {
				Set<ClassObject> classObjectsToBeExamined = new LinkedHashSet<ClassObject>();
				
				classObjectsToBeExamined.addAll(systemObject.getClassObjects());
				//&&(classObject.getName().equals(methodNameAndItsTargetName.get(method))||(classObject.getName().equals(method.getDeclaringType().getFullyQualifiedName())))
				final Set<String> classNamesToBeExamined = new LinkedHashSet<String>();
				for(ClassObject classObject : classObjectsToBeExamined) {
					if(!classObject.isEnum() && !classObject.isInterface() && !classObject.isGeneratedByParserGenenator())
						classNamesToBeExamined.add(classObject.getName());
				}
				MySystem system = new MySystem(systemObject, false);
				final DistanceMatrix distanceMatrix = new DistanceMatrix(system);
				final List<MoveMethodCandidateRefactoring> moveMethodCandidateList = new ArrayList<MoveMethodCandidateRefactoring>();

				ps.busyCursorWhile(new IRunnableWithProgress() {
					public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
						moveMethodCandidateList.addAll(distanceMatrix.getMoveMethodCandidateRefactoringsByAccess(classNamesToBeExamined, monitor));
					}
				});
				
				int flag = 0;
				int sum = 0;
				String className = null;
				for(MoveMethodCandidateRefactoring moveMethodRefactoring : moveMethodCandidateList){
					System.out.println("MoveMethodCandidateName------"+moveMethodRefactoring.getMovedMethodName()+"----class----"+moveMethodRefactoring.getSourceMethod().getClassOrigin());
					
					if(method.getElementName().equals(moveMethodRefactoring.getMovedMethodName())&&state == 1 ){
						flag = 1;
						className = method.getDeclaringType().getFullyQualifiedName();
						if(moveMethodRefactoring.getTarget().equals(className)){
							targetClassCorrect++;
							break;
						}		
					} 
					if(method.getElementName().equals(moveMethodRefactoring.getMovedMethodName())&&state == 0 ){
						flag = 2;
						className = method.getDeclaringType().getFullyQualifiedName();
						break;
					} 
					
				}
				System.out.println("flag--------------------------------------------------------------------------"+flag);
				if(flag == 1){
					MoveAndIsFE++;
				}
				if(flag == 2){
					NoMoveAndIsFE++;
				}
				System.out.println("TargeClassCorrect------------"+targetClassCorrect);
				System.out.println("MoveAndIsFE------------------"+MoveAndIsFE);
				System.out.println("NoMoveAndIsFE----------------"+NoMoveAndIsFE);
				
					
			}
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} 

		//return table;	

	}
	public int compareToCandidateList(String methodName){
		
		Standalone standalone = new Standalone();
		List<MoveMethodCandidateRefactoring> moveMethodCandidateList= standalone.getMoveMethodRefactoringOpportunities(iJavaProject);
		int flag = 0;
		for(MoveMethodCandidateRefactoring moveMethodRefactoring : moveMethodCandidateList){
			System.out.println("MoveMethodCandidateRefactoring---%%%---"+moveMethodRefactoring.getMovedMethodName());
			if(methodName == moveMethodRefactoring.getMovedMethodName()){
				flag = 1;
				break;
			}
		}
		return flag;
	}
	public void print(IMethod method){
		List<ICompilationUnit> iUnits = getAllCompilationUnits(iJavaProject);
		//System.out.println("@@@@@@@@@@@@@@@@@@@@@"+methodAndTarget.get(allMethods.get(i)).getType().getQualifiedName());
		try {
			for(ICompilationUnit iUnit : iUnits)
				for(IType type : iUnit.getAllTypes()){
					
					if(type.getFullyQualifiedName().equals(methodAndTarget.get(method).getType().getQualifiedName())){
						
						System.out.println("class name---"+type.getFullyQualifiedName());
						for(IMethod method0 : type.getMethods())
							System.out.println("method name------"+method0.getElementName());
					}
				}
		} catch (JavaModelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String methodParameters(MethodDeclaration methodDeclaration){
		IMethod method;
		ITypeBinding[] parameters = methodDeclaration.resolveBinding().getParameterTypes();
		List<String> parameterList = new ArrayList<String>();
		if(parameters.length!=0)
			for (ITypeBinding parameter : parameters){
				parameterList.add(parameter.getQualifiedName());
				//System.out.println("parameters------------"+parameter.getQualifiedName());
			}
		StringBuilder sb = new StringBuilder();
		if(!parameterList.isEmpty()){
			for(String parameter : parameterList)
				sb.append(parameter).append(",");
		}
		else
			sb.append("0");
		
		return sb.toString();
	}
	protected List<ICompilationUnit> getAllCompilationUnits(IJavaProject iJavaproject) {
		List<ICompilationUnit> allCompilationUnits = new ArrayList<ICompilationUnit>();
		if (iJavaproject == null) {
			return allCompilationUnits;
		}

		IPackageFragment[] packageFragments = getPackageFragments(iJavaproject);
		if (packageFragments == null) {
			return allCompilationUnits;
		}

		for (IPackageFragment packageFragment : packageFragments) {
			ICompilationUnit[] compilationUnits = getCompilationUnits(packageFragment);
			if (compilationUnits == null) {
				continue;
			}

			for (ICompilationUnit compilationUnit : compilationUnits) {
				if(!allCompilationUnits.contains(compilationUnit)){
					allCompilationUnits.add(compilationUnit);
				}
			}
		}
		return allCompilationUnits;
	}
	private IPackageFragment[] getPackageFragments(IJavaProject javaProject) {
		IPackageFragment[] packageFragments = null;

		try {
			packageFragments = javaProject.getPackageFragments();
		} catch (JavaModelException e) {
			return null;
		}

		return packageFragments;
	}

	private ICompilationUnit[] getCompilationUnits(
			IPackageFragment packageFragment) {
		try {
			if (packageFragment.getKind() != IPackageFragmentRoot.K_SOURCE) {
				return null;
			}
		} catch (JavaModelException e) {
			return null;
		}

		ICompilationUnit[] compilationUnits = null;

		try {
			compilationUnits = packageFragment.getCompilationUnits();
		} catch (JavaModelException e) {
			return null;
		}

		return compilationUnits;
	}
	public IProject getProject(){  
		IProject project = null;  
	//	IEditorPart part = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();  
		
		ISelectionService selectionService = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getSelectionService();    
		ISelection selection = selectionService.getSelection();    
		if(selection instanceof IStructuredSelection) {    
			Object element = ((IStructuredSelection)selection).getFirstElement();    
			
			if (element instanceof IResource) {    
				project= ((IResource)element).getProject();    
			} else if (element instanceof PackageFragmentRootContainer) {    
				IJavaProject jProject =     
						((PackageFragmentRootContainer)element).getJavaProject();    
				project = jProject.getProject();    
			} else if (element instanceof IJavaElement) {    
				IJavaProject jProject= ((IJavaElement)element).getJavaProject();    
				project = jProject.getProject();    
			}  
		}     
		
		return project;  
	} 
	
	class VisitorForMethod extends ASTVisitor{
		
		public boolean visit(TypeDeclaration node){
			if(!node.resolveBinding().equals(currentClass)){
				return false;
			}
			return true;
		}
		public boolean visit(EnumDeclaration node){
			return false;
		}
		
		public boolean visit(EnumConstantDeclaration node){
			return false;
		}
		
		public boolean visit(FieldDeclaration node){
				for (Object obj: node.fragments()) {  
		            VariableDeclarationFragment v = (VariableDeclarationFragment)obj;  
		            if(v.resolveBinding().getType().isFromSource() && !v.resolveBinding().getType().equals(currentClass)){
		            	IVarbindsCanMove.add(v.resolveBinding());
		            	MoveMethodNode node2 = new MoveMethodNode();
		            	
		            	if(v.resolveBinding().getType().isEnum())
		            		return true;
		            	if(!typeBindingCanMove.contains(v.resolveBinding().getType())){
		            		typeBindingCanMove.add(v.resolveBinding().getType());
		            	}
		            	
		            	
		            	boolean visited = false;
		            	for(MoveMethodNode nod: refactorNodes){
		            		if(nod.typeBinding.equals(v.resolveBinding().getType())){
		            			visited = true;
		            			nod.variableBindings.add(v.resolveBinding());
		            			break;
		            		}
		            	}
		            	
		            	if(visited == false){
		            		node2.typeBinding = v.resolveBinding().getType();
							List<IVariableBinding> vars = new ArrayList<>();
							vars.add(v.resolveBinding());
							node2.variableBindings = vars;
							node2.method = currentIMethod;
							node2.targetTypeName = v.resolveBinding().getType().getName();
							refactorNodes.add(node2);
		            	}
		            }
		        }
			return true;
		}
	}

}
