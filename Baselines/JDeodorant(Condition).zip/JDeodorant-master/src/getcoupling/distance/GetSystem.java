package getcoupling.distance;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Set;

import org.eclipse.jdt.core.IJavaProject;

import gr.uom.java.ast.ASTReader;
import gr.uom.java.ast.ClassObject;
import gr.uom.java.ast.CompilationErrorDetectedException;
import gr.uom.java.ast.CompilationUnitCache;
import gr.uom.java.ast.SystemObject;
import gr.uom.java.distance.ExtractClassCandidateGroup;
import gr.uom.java.distance.MySystem;

public class GetSystem {
	
	public static MySystem getMySystem(IJavaProject project) {
		CompilationUnitCache.getInstance().clearCache();
		
			if(ASTReader.getSystemObject() != null && project.equals(ASTReader.getExaminedProject())) {
				try {
					new ASTReader(project, ASTReader.getSystemObject(), null);
				} catch (CompilationErrorDetectedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else {
				try {
					new ASTReader(project, null);
				} catch (CompilationErrorDetectedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		
		
		SystemObject systemObject = ASTReader.getSystemObject();
		if(systemObject != null) {
			Set<ClassObject> classObjectsToBeExamined = new LinkedHashSet<ClassObject>();
			classObjectsToBeExamined.addAll(systemObject.getClassObjects());
			
			MySystem system = new MySystem(systemObject, true);
	
			return system;	
		}
		else{
			return new MySystem(null,false);
		}
	}

}
