package getcoupling.distance;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.internal.ui.packageview.PackageFragmentRootContainer;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.ISelectionService;
import org.eclipse.ui.PlatformUI;

import gr.uom.java.distance.DistanceCalculator;
import gr.uom.java.distance.Entity;
import gr.uom.java.distance.MyAttribute;
import gr.uom.java.distance.MyClass;
import gr.uom.java.distance.MyMethod;
import gr.uom.java.distance.MySystem;


public class GetIProject {
	
	private Map<String,Integer> entityIndexMap;
    private Map<String,Integer> classIndexMap;
	private List<Entity> entityList;
	private List<MyClass> classList;
    //holds the entity set of each entity
    private Map<String,Set<String>> entityMap;
    //holds the entity set of each class
    private Map<String,Set<String>> classMap;
    private double[][] distanceMatrix;
    public GetIProject(){
    	
    	entityIndexMap = new LinkedHashMap<String,Integer>();
        classIndexMap = new LinkedHashMap<String,Integer>();
        entityList = new ArrayList<Entity>();
        classList = new ArrayList<MyClass>();
        entityMap = new LinkedHashMap<String,Set<String>>();
        classMap = new LinkedHashMap<String,Set<String>>();
        
        
    }
	
	public void run(IJavaProject project){
		
//		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
//        IJavaProject project = JavaCore.create(root.getProject(getProject().toString()));
//		IProject selectedIProject = null;
//		System.out.println("Project   "+project.getElementName());
//		for (IProject iProject : root.getProjects()) {
//			if(iProject.getName().equals((project.getElementName()))){
//				selectedIProject = iProject;
//				break;
//			}	
//		 }		
//		System.out.println("IProject's  name----"+selectedIProject.getName());
		
//		MySystem system = GetSystem.getMySystem(project);		
//		generateDistances(system); 		
//		distanceMatrix = calculate(system);
		//excelDemo();
//		writeDistanceMatrics();
	}
	
	public void writeDistanceMatrics(){
		String filePath = "D:\\PrintDistanceMatrics.xlsx";
		try {
			FileOutputStream output = new FileOutputStream(filePath);
			//Workbook  workBook = new XSSFWorkbook ();
			XSSFWorkbook workbook = new XSSFWorkbook();
			for(int sheetIndex = 0; sheetIndex < 2; sheetIndex++){
				XSSFSheet sheet = workbook.createSheet("sheet" + sheetIndex);				
				for(int rowIndex = 0; rowIndex < 3; rowIndex++){				
					XSSFRow row = sheet.createRow(rowIndex);					
					if(rowIndex == 0){
						for (int j = 0; j<3; j++){
			    			 MyClass myclass=classList.get(j);
			    			 row.createCell(j + 1).setCellValue(myclass.getName());
			    		 }	
					}
					else {
						Entity entity =entityList.get(rowIndex - 1);					
						row.createCell(0).setCellValue(entity.toString());
						//System.out.println("distanceMatrix.length---------------------------------------"+distanceMatrix[rowIndex - 1].length);
						for (int j = 0; j<3; j++){ 
							row.createCell(j + 1).setCellValue(distanceMatrix[rowIndex - 1][j]);
							System.out.println("the value of distanceMatrix["+(rowIndex-1)+"]["+j+"]--------"+distanceMatrix[rowIndex - 1][j]);
			    		 }	
					}
					output.flush();
				}
			}
			workbook.write(output);
			output.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		 System.out.println("excel file generation");
	}
	
	 private void generateDistances(MySystem system) {
	    	Iterator<MyClass> classIt = system.getClassIterator();
	        while(classIt.hasNext()) {
	            MyClass myClass = classIt.next();
	            ListIterator<MyAttribute> attributeIterator = myClass.getAttributeIterator();
	            while(attributeIterator.hasNext()) {
	                MyAttribute attribute = attributeIterator.next();
	                if(!attribute.isReference()) {
	                    entityList.add(attribute);
	                    entityMap.put(attribute.toString(),attribute.getEntitySet());
	                }
	            }
	            ListIterator<MyMethod> methodIterator = myClass.getMethodIterator();
	            while(methodIterator.hasNext()) {
	                MyMethod method = methodIterator.next();
	                entityList.add(method);
	                entityMap.put(method.toString(),method.getEntitySet());
	            }
	            classList.add(myClass);
	            classMap.put(myClass.getName(),myClass.getEntitySet());
	        }

	        String[] entityNames = new String[entityList.size()];
	        String[] classNames = new String[classList.size()];
	        
	        int i = 0;
	        for(Entity entity : entityList) {
	            entityNames[i] = entity.toString();
	            entityIndexMap.put(entityNames[i],i);
	            int j = 0;
	            for(MyClass myClass : classList) {
	                classNames[j] = myClass.getName();
	                if(!classIndexMap.containsKey(classNames[j]))
	                    classIndexMap.put(classNames[j],j);
	                j++;
	            }
	            i++;
	        }
	    }
	
	public double[][] calculate(MySystem system){
		Iterator<MyClass> classIt = system.getClassIterator();
    	ArrayList<MyClass> oldClasses = new ArrayList<MyClass>();

    	while(classIt.hasNext()) {
    		MyClass myClass = classIt.next();
    		oldClasses.add(myClass);
    	}
    	double[][] distanceMatrix = null;
    	for(MyClass sourceClass : oldClasses) {
    		if (!sourceClass.getMethodList().isEmpty() && !sourceClass.getAttributeList().isEmpty()) {
    			distanceMatrix = getJaccardDistanceMatrix(sourceClass);
    		}
    	}
    	return distanceMatrix;
	}
	public IProject getProject(){  
		IProject project = null;  
//		IEditorPart part = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();  
 
		ISelectionService selectionService = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getSelectionService();    
		ISelection selection = selectionService.getSelection();    
		if(selection instanceof IStructuredSelection) {    
			Object element = ((IStructuredSelection)selection).getFirstElement();    
			
			if (element instanceof IResource) {    
				project= ((IResource)element).getProject();    
			} else if (element instanceof PackageFragmentRootContainer) {    
				IJavaProject jProject =     
						((PackageFragmentRootContainer)element).getJavaProject();    
				project = jProject.getProject();    
			} else if (element instanceof IJavaElement) {    
				IJavaProject jProject= ((IJavaElement)element).getJavaProject();    
				project = jProject.getProject();    
			}  
		}     
		
		
		return project;  
    }  
	
	public double[][] getJaccardDistanceMatrix(MyClass sourceClass) {
		System.out.println("sourceClass of name -------"+ sourceClass.getName());
		ArrayList<Entity> entities = new ArrayList<Entity>();
		//entities.addAll(sourceClass.getAttributeList());
		entities.addAll(sourceClass.getMethodList());
		//Set<String> sourceClassEntitySet = classMap.get(sourceClass);
		double[][] jaccardDistanceMatrix = new double[entities.size()][entities.size()];
		for(int i=0; i<jaccardDistanceMatrix.length; i++) {
			for(int j=0; j<jaccardDistanceMatrix.length; j++) {
				if(i != j) {
					jaccardDistanceMatrix[i][j] = DistanceCalculator.getDistance(entities.get(i).getFullEntitySet(), entities.get(j).getFullEntitySet());
//					if(i-j == 3){
//						System.out.println("entity class origin---"+sourceClass.getMethodList().get(j).getMethodName());
//						if(entities.get(j).getEntitySet().iterator().hasNext())
//							System.out.println("entity class origin---"+entities.get(j).getEntitySet().iterator().next());
//						System.out.println("jaccardDistanceMatrix["+i+"]["+j+"]��ֵ�ǣ�------  " + jaccardDistanceMatrix[i][j] );
//					}
				}
				else {
					jaccardDistanceMatrix[i][j] = 0.0;
				}
			}
		}
		return jaccardDistanceMatrix;
	}

}


