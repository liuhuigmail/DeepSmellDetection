package gr.uom.java.ast.decomposition.cfg;

import gr.uom.java.ast.decomposition.AbstractStatement;

public class CFGThrowNode extends CFGNode {

	public CFGThrowNode(AbstractStatement statement) {
		super(statement);
	}

}
