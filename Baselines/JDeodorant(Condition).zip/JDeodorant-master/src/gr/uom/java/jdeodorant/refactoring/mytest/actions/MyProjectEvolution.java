package gr.uom.java.jdeodorant.refactoring.mytest.actions;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.progress.IProgressService;

import gr.uom.java.ast.ASTReader;
import gr.uom.java.ast.ClassObject;
import gr.uom.java.ast.CompilationErrorDetectedException;
import gr.uom.java.ast.Standalone;
import gr.uom.java.ast.SystemObject;
import gr.uom.java.distance.DistanceMatrix;
import gr.uom.java.distance.MoveMethodCandidateRefactoring;
import gr.uom.java.distance.MySystem;
import gr.uom.java.jdeodorant.refactoring.mytest.actions.movemethod.MethodEntity;
import gr.uom.java.jdeodorant.refactoring.mytest.actions.movemethod.RelatedClass;


public class MyProjectEvolution {
	
	protected IJavaProject iJavaproject = null;
	protected IProject iProject = null;
	public List<ICompilationUnit> compilationUnits = new ArrayList<ICompilationUnit>();
	public List<IType> types = new ArrayList<IType>();
	public List<IMethod> allMethods = new ArrayList<IMethod>();
	public Map<IMethod, IType> MethodAndItsClass = new HashMap<IMethod, IType>();
	public Map<IMethod,MethodDeclaration> methodAndItsMehthodDeclaration = new HashMap<IMethod, MethodDeclaration>();
	
	public MyProjectEvolution(IJavaProject selectedProject, IProject selectedIProject){
		this.iJavaproject = selectedProject;
		this.iProject = selectedIProject;
		compilationUnits = getAllCompilationUnits();
		
		}

	public void run() throws Exception{
		getAllITypesAndAllIMethods();

		System.out.println("all class's sum ------" + types.size());
		System.out.println("all method's sum ------" + allMethods.size());
		try {
			new ASTReader(iJavaproject, null);
		} catch (CompilationErrorDetectedException e) {
			// TODO Auto-generated catch block
			System.out.println("----CompilationErrorDetectedException");
		}
		getTable(iJavaproject);
		GetAllIMethodAndAllMethodDeclaration();
		Standalone standalone = new Standalone();
		List<MoveMethodCandidateRefactoring> moveMethodCandidateList= standalone.getMoveMethodRefactoringOpportunities(iJavaproject);

		RelatedClass relatedClass = new RelatedClass(iProject,iJavaproject);
		for(int i=470; i<types.size(); i++){
			System.out.println(i+"----"+types.get(i).getFullyQualifiedName());
			relatedClass.getMoveMethodCandidates(types.get(i));
		}

		
		compareTable(iJavaproject);

		
	}
	private  void compareTable(IJavaProject iJavaProject){
		try{
			new ASTReader(iJavaProject, null);
			
			IWorkbench wb = PlatformUI.getWorkbench();
			IProgressService ps = wb.getProgressService();

			SystemObject systemObject = ASTReader.getSystemObject();
			if(systemObject != null) {
				Set<ClassObject> classObjectsToBeExamined = new LinkedHashSet<ClassObject>();
				
				classObjectsToBeExamined.addAll(systemObject.getClassObjects());	
				final Set<String> classNamesToBeExamined = new LinkedHashSet<String>();
				for(ClassObject classObject : classObjectsToBeExamined) {
					if(!classObject.isEnum() && !classObject.isInterface() && !classObject.isGeneratedByParserGenenator())
						classNamesToBeExamined.add(classObject.getName());
				}
				MySystem system = new MySystem(systemObject, false);
				final DistanceMatrix distanceMatrix = new DistanceMatrix(system);
				final List<MoveMethodCandidateRefactoring> moveMethodCandidateList = new ArrayList<MoveMethodCandidateRefactoring>();

				ps.busyCursorWhile(new IRunnableWithProgress() {
					public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
						moveMethodCandidateList.addAll(distanceMatrix.getMoveMethodCandidateRefactoringsByAccess(classNamesToBeExamined, monitor));
					}
				});

				File file = new File("D:\\TSE\\featureenvy\\CompareProjects-ori\\MoveMethodNameAndState_"+iProject.getName()+".txt");
				StringBuilder result = new StringBuilder();
				BufferedReader reader = new BufferedReader(new FileReader(file));
	            String s = null;
	            /////////////////////////////////////////////////////////////
	            List<MoveMethodCandidateRefactoring> methods=distanceMatrix.methods;
	            List<Double> distances=distanceMatrix.distances;
	            double[] labels=new double[distances.size()];
	            double[] score=new double[distances.size()];
	            int temp=0,cnt=0;
	            
	            String tt="";
	            
	            while((s = reader.readLine())!=null){

	            	String[] splitString = s.split(" ");
	            	String methodName1= splitString[0];
	            	String parameters = splitString[1];
	            	String className1 = splitString[2];
	            	String targetClassName = splitString[3];
	            	int state =0;
	            	if(splitString[4].length()!=1){
	            		parameters = splitString[1]+' '+splitString[2]+' '+splitString[3];
	            		className1 = splitString[4];
	            		targetClassName = splitString[5];
	                	state = Integer.parseInt(splitString[6]);
	            	}else
	            		state = Integer.parseInt(splitString[4]);
	            	cnt++;

	            	for(int k=0;k<methods.size();k++){
	            		MoveMethodCandidateRefactoring moveMethodRefactoring=methods.get(k);
	            		if(methodName1.equals(moveMethodRefactoring.getMovedMethodName())&&className1.equals(moveMethodRefactoring.getSource())&&parameters.equals(methodParameters(moveMethodRefactoring.getSourceMethodDeclaration()))&&state==0){
	            			//labels.add(new Double(0));
	            			labels[temp]=0;
	            			score[temp]=distances.get(k);
	            			temp++;
	            			break;
	            		}
	            		if(methodName1.equals(moveMethodRefactoring.getMovedMethodName())&&state==1){
	            			labels[temp]=1;
	            			score[temp]=distances.get(k);
            				temp++;
            				break;
            			}
	            		
	            	}
	            }
	            reader.close();  
	            
	            System.out.println("Done!!!!!");
			}
		}catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}catch (CompilationErrorDetectedException e) {
			// TODO Auto-generated catch block
			System.out.println("----CompilationErrorDetectedException");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	public String methodParameters(MethodDeclaration methodDeclaration){
		IMethod method;
		ITypeBinding[] parameters = methodDeclaration.resolveBinding().getParameterTypes();
		List<String> parameterList = new ArrayList<String>();
		if(parameters.length!=0)
			for (ITypeBinding parameter : parameters){
				parameterList.add(parameter.getQualifiedName());
				//System.out.println("parameters------------"+parameter.getQualifiedName());
			}
		StringBuilder sb = new StringBuilder();
		if(!parameterList.isEmpty()){
			for(String parameter : parameterList)
				sb.append(parameter).append(",");
		}
		else
			sb.append("0");
		
		return sb.toString();
	}
	private void getTable( IJavaProject iJavaProject) {
		//System.out.println("1111111111111111111111111");
		IWorkbench wb = PlatformUI.getWorkbench();
		IProgressService ps = wb.getProgressService();

		SystemObject systemObject = ASTReader.getSystemObject();
		if(systemObject != null) {
			Set<ClassObject> classObjectsToBeExamined = new LinkedHashSet<ClassObject>();
			
			classObjectsToBeExamined.addAll(systemObject.getClassObjects());
			//&&(classObject.getName().equals(methodNameAndItsTargetName.get(method))||(classObject.getName().equals(method.getDeclaringType().getFullyQualifiedName())))
			final Set<String> classNamesToBeExamined = new LinkedHashSet<String>();
			for(ClassObject classObject : classObjectsToBeExamined) {
				if(!classObject.isEnum() && !classObject.isInterface() && !classObject.isGeneratedByParserGenenator())
					classNamesToBeExamined.add(classObject.getName());
			}
			MySystem system = new MySystem(systemObject, false);
			final DistanceMatrix distanceMatrix = new DistanceMatrix(system);
			final List<MoveMethodCandidateRefactoring> moveMethodCandidateList = new ArrayList<MoveMethodCandidateRefactoring>();
			//System.out.println("22222222222222222222222222222222");
			try {
				ps.busyCursorWhile(new IRunnableWithProgress() {
					public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
						moveMethodCandidateList.addAll(distanceMatrix.getMoveMethodCandidateRefactoringsByAccess(classNamesToBeExamined, monitor));
					}
				});
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			for(MoveMethodCandidateRefactoring moveMethodRefactoring : moveMethodCandidateList){
				System.out.println("MethodName------"+moveMethodRefactoring.getMovedMethodName()+"----class----"+moveMethodRefactoring.getSourceMethod().getClassOrigin()+"------targetClass------"+moveMethodRefactoring.getTarget()+"\n");
				
			}
			
		}
	//return table;	

}
	void init(){
		MethodAndItsClass.clear();
		allMethods.clear();
		methodAndItsMehthodDeclaration.clear();
		types.clear();
	}
	public void getAllITypesAndAllIMethods(){
		for(ICompilationUnit compilationUnit : compilationUnits){
			if(!compilationUnit.exists())
				continue;
			IType[] classes = null;
			try {
				
				classes = compilationUnit.getTypes();
			} catch (JavaModelException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			for(IType type : classes){
				try {
					if(type.isClass()){
						types.add(type);
						IMethod[] approches = null;
						approches = type.getMethods();
						for(IMethod method : approches){
							
							allMethods.add(method);
							MethodAndItsClass.put(method, type);
						}	
					}
				} catch (JavaModelException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		}	
	}

	public void GetAllIMethodAndAllMethodDeclaration() throws Exception{
		for(IMethod method : allMethods){
			System.out.println("method of name---------///////////////////////"+method.getElementName());
			MethodEntity entity = new MethodEntity(method);
			MethodDeclaration methodDeclaration = (MethodDeclaration) entity.getAssociatedNode();
//			MethodAndItsRelationedClass relatedClass = new MethodAndItsRelationedClass(types, allMethods);
//			relatedClass.addMethodInfo(method, methodDeclaration);
//			methodAndItsMehthodDeclaration.put(method, methodDeclaration);
		}
	}
	
	
	public void print(){
		for(IType type : types){
			System.out.println("type of name ---"+type.getElementName());
		}
		for(IMethod method : allMethods){
			System.out.println("method of name ---"+method.getElementName());
		}
	}
	
	protected List<ICompilationUnit> getAllCompilationUnits() {
		List<ICompilationUnit> allCompilationUnits = new ArrayList<ICompilationUnit>();
		if (iJavaproject == null) {
			return allCompilationUnits;
		}

		IPackageFragment[] packageFragments = getPackageFragments(iJavaproject);
		if (packageFragments == null) {
			return allCompilationUnits;
		}

		for (IPackageFragment packageFragment : packageFragments) {
			ICompilationUnit[] compilationUnits = getCompilationUnits(packageFragment);
			if (compilationUnits == null) {
				continue;
			}

			for (ICompilationUnit compilationUnit : compilationUnits) {
				if(!allCompilationUnits.contains(compilationUnit)){
					allCompilationUnits.add(compilationUnit);
				}
			}
		}
		return allCompilationUnits;
	}

	private IPackageFragment[] getPackageFragments(IJavaProject javaProject) {
		IPackageFragment[] packageFragments = null;

		try {
			packageFragments = javaProject.getPackageFragments();
		} catch (JavaModelException e) {
			return null;
		}

		return packageFragments;
	}

	private ICompilationUnit[] getCompilationUnits(
			IPackageFragment packageFragment) {
		try {
			if (packageFragment.getKind() != IPackageFragmentRoot.K_SOURCE) {
				return null;
			}
		} catch (JavaModelException e) {
			return null;
		}

		ICompilationUnit[] compilationUnits = null;

		try {
			compilationUnits = packageFragment.getCompilationUnits();
		} catch (JavaModelException e) {
			return null;
		}

		return compilationUnits;
	}
	
	protected CompilationUnit createCompilationUnit(ICompilationUnit compilationUnit) {
		ASTParser parser = ASTParser.newParser(AST.JLS4);
	//	parser.setProject(iJavaproject);
		parser.setSource(compilationUnit);
		parser.setProject(compilationUnit.getJavaProject());
		//Config.projectName=compilationUnit.getJavaProject().getElementName();
	//	System.out.println("��Ŀ���ƣ�"+compilationUnit.getJavaProject().getElementName());
		IPath path=compilationUnit.getPath();
		parser.setUnitName(path.toString());
		parser.setResolveBindings(true);
		parser.setStatementsRecovery(true);
		CompilationUnit unit=null;
		try
		{
			unit= (CompilationUnit) parser.createAST(null);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return unit;
	}
	
}
