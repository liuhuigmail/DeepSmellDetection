package gr.uom.java.jdeodorant.refactoring.mytest.actions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.progress.IProgressService;

import gr.uom.java.ast.ASTReader;
import gr.uom.java.ast.ClassObject;
import gr.uom.java.ast.CompilationErrorDetectedException;
import gr.uom.java.ast.SystemObject;
import gr.uom.java.distance.DistanceMatrix;
import gr.uom.java.distance.MoveMethodCandidateRefactoring;
import gr.uom.java.distance.MySystem;

public class CalIntersection {

	public void calintersection(IJavaProject iJavaProject) {
		try {
			new ASTReader(iJavaProject, null);
			
			IWorkbench wb = PlatformUI.getWorkbench();
			IProgressService ps = wb.getProgressService();
	
			SystemObject systemObject = ASTReader.getSystemObject();
			if(systemObject != null) {
				Set<ClassObject> classObjectsToBeExamined = new LinkedHashSet<ClassObject>();
				
				classObjectsToBeExamined.addAll(systemObject.getClassObjects());
				//&&(classObject.getName().equals(methodNameAndItsTargetName.get(method))||(classObject.getName().equals(method.getDeclaringType().getFullyQualifiedName())))
				final Set<String> classNamesToBeExamined = new LinkedHashSet<String>();
				for(ClassObject classObject : classObjectsToBeExamined) {
					if(!classObject.isEnum() && !classObject.isInterface() && !classObject.isGeneratedByParserGenenator())
						classNamesToBeExamined.add(classObject.getName());
				}
				MySystem system = new MySystem(systemObject, false);
				final DistanceMatrix distanceMatrix = new DistanceMatrix(system);
				final List<MoveMethodCandidateRefactoring> moveMethodCandidateList = new ArrayList<MoveMethodCandidateRefactoring>();
	
				ps.busyCursorWhile(new IRunnableWithProgress() {
					public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
						moveMethodCandidateList.addAll(distanceMatrix.getalldistance(classNamesToBeExamined, monitor));
					}
				});


	        }


	            
	//            File file1 = new File("D:\\TSE\\featureenvy\\auc_"+iProject.getName()+".txt");
	//            file1.createNewFile();
	//			FileWriter writer=new FileWriter(file1);
	//			BufferedWriter out=new BufferedWriter(writer);
	//			for(int i=0;i<distances.size();i++){
	//				out.write(""+distances.get(i).doubleValue()+" "+labels[i]+"\r\n");
	//			}
	//			out.close();
	//			writer.close();
	            
				
	//            File file1 = new File("D:\\exp.txt");
	//            file1.createNewFile();
	//			FileWriter writer=new FileWriter(file1);
	//			BufferedWriter out=new BufferedWriter(writer);
	//			out.write(tt);
	//			out.close();
	//			writer.close();
	            
	            System.out.println("Done!!!!!");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	

}
