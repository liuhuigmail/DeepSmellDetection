package swr.init;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
    
    static {
        NLS.initializeMessages("messages", Messages.class);  
    }

	public Messages() {		
	}

	public static String Sample0;
	
	public static String Sample1;

    public static String Sample2;
    
    public static String Sample3;
	   
}
