package swr.actions.combine.manuallabel;

import java.io.IOException;

import org.eclipse.core.resources.IFile;

import com.csvreader.CsvReader;

public class ReadLabels {
	
	public void readCSV(IFile csvPath) throws IOException{

	}
	
}
