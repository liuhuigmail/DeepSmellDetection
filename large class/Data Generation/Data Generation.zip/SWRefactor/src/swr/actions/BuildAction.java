package swr.actions;

import java.util.Map;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

public class BuildAction extends IncrementalProjectBuilder{

    @Override
    protected IProject[] build(int arg0, Map<String, String> arg1, IProgressMonitor arg2) throws CoreException {
        // TODO Auto-generated method stub
    		//System.out.println("build");
    		
        return null;
    }
    @Override
    protected void startupOnInitialize() {
//    		System.out.println("startupOnInitialize");
        // add builder init logic here
     }
    @Override
     protected void clean(IProgressMonitor monitor) {
        // add builder clean logic here
//    		System.out.println("clean");
     }    
}
