package condition;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class CalCondition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			ArrayList<Double> dis0=new ArrayList<Double>();
			ArrayList<Double> dis1=new ArrayList<Double>();
			Class.forName("com.mysql.jdbc.Driver");
			
	        Connection conn = DriverManager.getConnection(
	                "jdbc:mysql://127.0.0.1:3306/misplaceclass?serverTimezone=GMT",
	                "root","123456");
	        PreparedStatement ps1=conn.prepareStatement("select * from classinfo");
	        PreparedStatement ps2=conn.prepareStatement("select * from input where classqualifiedname=? and ori_package=?");
	        //PreparedStatement ps3=conn.prepareStatement("select intersection from intersection where classname=? and packagename=?");
	        PreparedStatement ps4=conn.prepareStatement("select * from input where classqualifiedname=?");
	        PreparedStatement ps5=conn.prepareStatement("insert into input_condition values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	        
	        int a=0;
	        int b=0;
	        ResultSet rs1=ps1.executeQuery();
	        int ith=1;
	        while(rs1.next()) {
	        	System.out.println((ith++)+" / 8970");
	        	String ori_pac=rs1.getString(2);
	        	String classname=rs1.getString(3);
	        	ps2.setString(1, classname);
	        	ps2.setString(2, ori_pac);
	        	
	        	double ori_inter=0;
	        	double tar_inter=0;
	        	
	        	ResultSet rs2=ps2.executeQuery();
	        	while(rs2.next()) {
	        		String targetname=rs2.getString("tar_package");
	        		ori_inter=rs2.getDouble("ori_MPC_sum");
		        	double t=rs2.getDouble("tar_MPC_sum");
		        	if(t>tar_inter) tar_inter=t;

	        	}
	        	
	        	rs2.close();
	        	
	        	if(ori_inter==tar_inter) {
	        		a++;
	        		if(ori_inter==0)
	        			b++;
	        	}
	        	
	        	if(ori_inter<=tar_inter) continue;
	        	double v=ori_inter-tar_inter;
	        	dis0.add(v);
	        	
	        	ps4.setString(1, classname);
	        	ResultSet rs4=ps4.executeQuery();
	        	
	        	
	        	
	        	while(rs4.next()) {
//	        		if(rs4.getDouble(15)==0)
//	        			dis0.add(v);
//	        		else
//	        			dis1.add(v);

	        		ps5.setString(1, rs4.getString(1));
	        		ps5.setString(2, rs4.getString(2));
	        		ps5.setString(3, rs4.getString(3));
	        		ps5.setString(4, rs4.getString(4));
	        		ps5.setString(5, rs4.getString(5));
	        		ps5.setString(6, rs4.getString(6));
	        		
	        		ps5.setDouble(7, rs4.getDouble(7));
	        		ps5.setDouble(8, rs4.getDouble(8));
	        		ps5.setDouble(9, rs4.getDouble(9));
	        		ps5.setDouble(10, rs4.getDouble(10));
	        		ps5.setDouble(11, rs4.getDouble(11));
	        		ps5.setDouble(12, rs4.getDouble(12));
	        		ps5.setDouble(13, rs4.getDouble(13));
	        		ps5.setDouble(14, rs4.getDouble(14));
	        		ps5.setDouble(15, rs4.getDouble(15));
	        		ps5.execute();
	        	}
	        	
	        }
	        System.out.println(a+"  "+b);
	        System.out.println("Done");
//	        Collections.sort(dis0);
//	        Collections.sort(dis1);
//	        for(int i=0;i<dis0.size();i++) {
//	        	System.out.println(dis0.get(i));
//	        }
//	        System.out.println("----------------------------------");
//	        for(int i=0;i<dis1.size();i++) {
//	        	System.out.println(dis1.get(i));
//	        }
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	

}
