package taco;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;

public class tacovisitor extends ASTVisitor{
	public boolean visit(SimpleName node) {
		if(node.resolveBinding()!=null)
			System.out.println(node.resolveBinding().getJavaElement().getElementName());
		return true;
	}
	
}