package gdata.handlers;

import java.util.List;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.InvocationTargetException;


import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.internal.ui.packageview.PackageFragmentRootContainer;
import org.eclipse.jdt.ui.wizards.JavaCapabilityConfigurationPage;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.ISelectionService;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPartSite;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.progress.IProgressService;

import gdata.generate.EncodingDetect;
import gdata.generate.Runner;
import gdata.generate.TEMP;
/**
 * Our sample handler extends AbstractHandler, an IHandler base class.
 * @see org.eclipse.core.commands.IHandler
 * @see org.eclipse.core.commands.AbstractHandler
 */
public class SampleHandler extends AbstractHandler {

	public static String projectname="android-backup-extractor-20140630";
	public static IProject project=null;
	public static IJavaProject jproject=null;
	public static int ith=0;
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		
		
		
		
//		System.out.println("Start Running ... ");
//		try {
//			System.out.println(projectname);
//
//			importProject();
//			Runner r=new Runner();
//			r.run();
//
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println("Done!!!");
		
		
		
		
		long[] ttt=new long[15];
		
		
		ISelectionService selectionService = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getSelectionService();    
		ISelection selection = selectionService.getSelection();  
		if(selection instanceof IStructuredSelection) {
			List temp=((IStructuredSelection)selection).toList();
			for(int i=0;i<temp.size();i++) {
				IProject tproject=null;
				Object element = temp.get(i);    
				
				if (element instanceof IResource) {    
					tproject= ((IResource)element).getProject();  
				} else if (element instanceof PackageFragmentRootContainer) {    
					IJavaProject jProject =     
							((PackageFragmentRootContainer)element).getJavaProject();    
					tproject = jProject.getProject();    
				} else if (element instanceof IJavaElement) {    
					IJavaProject jProject= ((IJavaElement)element).getJavaProject();    
					tproject = jProject.getProject();    
				}
				
				IJavaProject selectedProject = JavaCore.create(tproject);
				System.out.println("-------------------------------------------------------\r\n"+selectedProject.getElementName());
				EncodingDetect ed=new EncodingDetect(); 
				try {
					SampleHandler.jproject=selectedProject;
					SampleHandler.project=tproject;
					Runner r=new Runner();
					ttt[i]=r.run();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				System.out.println("Done!!!!");
			}
		}
//		System.out.println("##################################");
//		for(int i=0;i<10;i++) {
//			System.out.println(ttt[i]);
//		}
		return null;
	}
	
	
	public static void importProject() throws Exception {
		copy("D:\\TSE\\misplaceclass\\datageneration\\backup\\"+projectname,"D:\\TSE\\misplaceclass\\datageneration\\"+projectname);
		
		IWorkspaceRoot root= ResourcesPlugin.getWorkspace().getRoot();
		 
		final IWorkspace workspace = ResourcesPlugin.getWorkspace();
		 
		System.out.println("root" + root.getLocation().toOSString());
		 
		Runnable runnable = new Runnable() {
			public void run() {
				try {
					IPath projectDotProjectFile = new Path("D:\\TSE\\misplaceclass\\datageneration\\"+projectname+"\\.project");
					IProjectDescription projectDescription = workspace.loadProjectDescription(projectDotProjectFile);
					IProject project = workspace.getRoot().getProject(projectDescription.getName());
					JavaCapabilityConfigurationPage.createProject(project, projectDescription.getLocationURI(),	null);
					//project.create(null);
				} catch (CoreException e) {
					e.printStackTrace();
				}
			}
		};
		 
		// and now get the workbench to do the work
		final IWorkbench workbench = PlatformUI.getWorkbench();
		workbench.getDisplay().syncExec(runnable);

		IProject[] projects = root.getProjects();
		
		for(IProject tproject: projects) if(tproject.getName().equals(projectname)){
			project=tproject;
			jproject=JavaCore.create(project);
			System.out.println("Imported");
			break;
		}
		
	}
	
	public static void deleteProject(){
		try {
			jproject.close();
			project.delete(true, true, null);
			deleteDir("D:\\TSE\\misplaceclass\\datageneration\\"+projectname);
			ith++;
			System.out.println("Deleted");
		}catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public static void deleteDir(String dirPath)
	{
		File file = new File(dirPath);
		if(file.isFile())
		{
			file.delete();
		}else
		{
			File[] files = file.listFiles();
			if(files == null)
			{
				file.delete();
			}else
			{
				for (int i = 0; i < files.length; i++) 
				{
					deleteDir(files[i].getAbsolutePath());
				}
				file.delete();
			}
		}
	}

	public static void copy(String src, String des) throws Exception {
        //��ʼ���ļ�����
        File file1=new File(src);
        //���ļ��������ݷŽ�����
        File[] fs=file1.listFiles();
        //��ʼ���ļ�ճ��
        File file2=new File(des);
        //�ж��Ƿ�������ļ��в���û�д���
        if(!file2.exists()){
            file2.mkdirs();
        }
        //�����ļ����ļ���
        for (File f : fs) {
            if(f.isFile()){
                //�ļ�
                fileCopy(f.getPath(),des+"\\"+f.getName()); //�����ļ������ķ���
            }else if(f.isDirectory()){
                //�ļ���
                copy(f.getPath(),des+"\\"+f.getName());//�������ø��Ʒ���      �ݹ�ĵط�,�Լ������Լ��ķ���,�Ϳ��Ը����ļ��е��ļ�����
            }
        }
        
    }

    private static void fileCopy(String src, String des) throws Exception {
        //io���̶���ʽ
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(src));
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(des));
        int i = -1;//��¼��ȡ����
        byte[] bt = new byte[2014];//������
        while ((i = bis.read(bt))!=-1) {
            bos.write(bt, 0, i);
        }
        bis.close();
        bos.close();
        //�ر���
    }
}
