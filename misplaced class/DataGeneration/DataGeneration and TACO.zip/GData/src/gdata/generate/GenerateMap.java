package gdata.generate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IType;

public class GenerateMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/misplaceclass", "root", "123456");
			PreparedStatement ps1=conn.prepareStatement("select * from taco_temp");
			ResultSet rs1=ps1.executeQuery();
			while(rs1.next()) {
				
			}

			
			

			
			ps1.close();

			conn.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void generatePackageMap() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/misplaceclass", "root", "123456");
			PreparedStatement ps1=conn.prepareStatement("select * from test_class");
			PreparedStatement ps0=conn.prepareStatement("select * from test_items where classqualifiedname=?");
			PreparedStatement ps2=conn.prepareStatement("insert into taco_package values(?,?)");
			PreparedStatement ps3=conn.prepareStatement("select * from taco_temp where classname=?");
			ResultSet rs=ps1.executeQuery();
			int cnt=0;
			int index=1;
			while(rs.next()) {
				
				String classname2=rs.getString("qualifiedclassname");
				ps0.setString(1, classname2);
				ResultSet rs1=ps0.executeQuery();
				while(rs1.next()) {
				
				
					String classname1=rs1.getString("packagename")+"."+rs1.getString("classname");
					ps2.setString(1, classname1);
					ps2.setString(2, classname2);
					ps2.execute();
					
					ps3.setString(1, classname1);
					ResultSet trs=ps3.executeQuery();
					cnt++;
					while(trs.next()) {
						cnt--;
					}
					break;
				}
				
				if(index%100==0)
					System.out.println(index);
				index++;
			}
			System.out.println(cnt);
			
			ps1.close();
			ps2.close();
			ps3.close();
			conn.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
