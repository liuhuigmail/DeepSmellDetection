package gdata.generate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javafx.util.*;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.FieldAccess;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.PrimitiveType;
import org.eclipse.jdt.core.dom.SimpleType;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;

public class MetricsCalculator {
	
	ArrayList<IPackageFragment> pfs;
	ArrayList<ICompilationUnit> icus;
	ArrayList<IType> types;
	Map<ICompilationUnit,Integer> pos;
	
	double[][] CBOs;
	
	public MetricsCalculator(ArrayList<IPackageFragment> pfs, ArrayList<ICompilationUnit> icus, ArrayList<IType> types) {
		this.pfs=pfs;
		this.icus=icus;
		this.types=types;
		CBOs=new double[icus.size()][icus.size()];
		pos=new HashMap<ICompilationUnit,Integer>(); 
		for(int i=0;i<icus.size();i++) { 
			pos.put(icus.get(i), new Integer(i));
			for(int j=i;j<icus.size();j++) CBOs[i][j]=CBOs[j][i]=0;
		}
		
		for(int i=0;i<icus.size();i++) {
			ICompilationUnit icu=icus.get(i);
			
			//if(!icu.getElementName().equals("WritableSheet.java")) continue;
			
			
			ASTParser astParser=ASTParser.newParser(AST.JLS10);
			astParser.setSource(icu);
			astParser.setKind(ASTParser.K_COMPILATION_UNIT);
			astParser.setResolveBindings(true);
			astParser.setBindingsRecovery(true);
			//astParser.setProject(jproject);
			CompilationUnit cu=(CompilationUnit) (astParser.createAST(null));
			
			MyVisitorCBO visCBO=new MyVisitorCBO(types.get(i).getElementName());
			cu.accept(visCBO);
			
			ArrayList<ICompilationUnit> related_icus=visCBO.related_icus;
			for(int j=0;j<related_icus.size();j++) {
				ICompilationUnit a=related_icus.get(j);
				if(pos.get(a)==null) continue;
				int index=pos.get(a).intValue();
				CBOs[i][index]=CBOs[index][i]=1;
			}
		}
//		for(int i=0;i<icus.size();i++) System.out.println(icus.get(i).getElementName()+"  ");
//		for(int i=0;i<icus.size();i++) { 
//			for(int j=0;j<icus.size();j++) System.out.print(CBOs[i][j]+"  ");
//			System.out.println("");
//		}

	}
	
	
	
	
	public int calculateCBO(ICompilationUnit icu, IPackageFragment pf) throws JavaModelException {
		int res=0;
		int i=pos.get(icu).intValue();
		for(ICompilationUnit a: pf.getCompilationUnits()) {
			if(pos.get(a)==null) continue;
			int j=pos.get(a).intValue();
			if(CBOs[i][j]==1) res++;
		}
		return res;
	}
	
	public Map<ICompilationUnit,Integer> calculateMPC(ICompilationUnit icu,IPackageFragment pf) throws JavaModelException {
		Map<ICompilationUnit,Integer> res=new HashMap<ICompilationUnit,Integer>();


		for(ICompilationUnit ticu : pf.getCompilationUnits()) {
			res.put(ticu, new Integer(0));
		}
		
		ASTParser astParser=ASTParser.newParser(AST.JLS10);
		astParser.setSource(icu);
		astParser.setKind(ASTParser.K_COMPILATION_UNIT);
		astParser.setResolveBindings(true);
		astParser.setBindingsRecovery(true);
		//astParser.setProject(jproject);
		CompilationUnit cu=(CompilationUnit) (astParser.createAST(null));
		
		MyVisitorMPC visMPC=new MyVisitorMPC();
		cu.accept(visMPC);
		
		for(int i=0;i<visMPC.t_pfs.size();i++) {
			IPackageFragment t_pf=visMPC.t_pfs.get(i);
			ICompilationUnit ticu=visMPC.t_icus.get(i);

			Integer cnt=res.get(ticu);
			if(cnt!=null) {
				cnt++;
				res.put(ticu, cnt);
			}
		}
		return res;
	}

}



