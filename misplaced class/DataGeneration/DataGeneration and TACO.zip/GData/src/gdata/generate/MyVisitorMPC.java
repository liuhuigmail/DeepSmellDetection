package gdata.generate;

import java.util.ArrayList;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.FieldAccess;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.MethodInvocation;

class MyVisitorMPC extends ASTVisitor{
	
	public ArrayList<IPackageFragment> t_pfs;
	public ArrayList<ICompilationUnit> t_icus;
	
	public MyVisitorMPC() {
		t_pfs=new ArrayList<IPackageFragment>();
		t_icus=new ArrayList<ICompilationUnit>();
	}
	
	@Override
	public boolean visit(MethodInvocation node) {
		//System.out.println(node.resolveMethodBinding().getDeclaringClass().getQualifiedName());
		if(node.resolveMethodBinding()==null) return true;
		ITypeBinding type=node.resolveMethodBinding().getDeclaringClass();
		if(type==null||type.getPackage()==null) return true;
		IPackageFragment pf=(IPackageFragment)(type.getPackage().getJavaElement());
		if((type.getJavaElement().getParent()) instanceof ICompilationUnit) {
			ICompilationUnit icu=(ICompilationUnit)(type.getJavaElement().getParent());
			
			t_pfs.add(pf);
			t_icus.add(icu);
		}

		return true;
	}
	
	@Override
	public boolean visit(FieldAccess node) {
		//System.out.println("----"+node.resolveTypeBinding().getName());
		ITypeBinding type=node.resolveTypeBinding();
		if(type==null||type.getPackage()==null) return true;
		IPackageFragment pf=(IPackageFragment)(type.getPackage().getJavaElement());
		if((type.getJavaElement().getParent()) instanceof ICompilationUnit) {
			ICompilationUnit icu=(ICompilationUnit)(type.getJavaElement().getParent());
			
			t_pfs.add(pf);
			t_icus.add(icu);
		}
		
		return true;
	}
	
}