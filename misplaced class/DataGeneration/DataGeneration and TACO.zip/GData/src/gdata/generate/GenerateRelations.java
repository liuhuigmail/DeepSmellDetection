package gdata.generate;

import java.lang.reflect.InvocationTargetException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Random;

import javax.management.Query;

import org.eclipse.core.commands.operations.IUndoContext;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaModel;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.internal.corext.refactoring.reorg.IReorgDestination;
import org.eclipse.jdt.internal.corext.refactoring.reorg.JavaMoveProcessor;
import org.eclipse.jdt.internal.corext.refactoring.reorg.ReorgDestinationFactory;
import org.eclipse.jdt.internal.corext.refactoring.reorg.ReorgPolicyFactory;
import org.eclipse.jdt.internal.corext.refactoring.reorg.IReorgPolicy.IMovePolicy;
import org.eclipse.jdt.internal.ui.refactoring.reorg.ReorgQueries;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.ltk.core.refactoring.CheckConditionsOperation;
import org.eclipse.ltk.core.refactoring.IValidationCheckResultQuery;
import org.eclipse.ltk.core.refactoring.PerformRefactoringOperation;
import org.eclipse.ltk.core.refactoring.RefactoringCore;
import org.eclipse.ltk.core.refactoring.RefactoringStatus;
import org.eclipse.ltk.core.refactoring.participants.MoveRefactoring;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchPartSite;
import org.eclipse.ui.PlatformUI;

import gr.uom.java.ast.ASTReader;
import gr.uom.java.ast.CompilationErrorDetectedException;

public class GenerateRelations {
	
	IJavaProject jproject;
	Shell shell;
	ArrayList<IPackageFragment> pfs;
	ArrayList<ICompilationUnit> icus;
	ArrayList<IType> types;
	private Runtime run;
	public GenerateRelations(ArrayList<IPackageFragment> pfs,ArrayList<ICompilationUnit> icus,ArrayList<IType> types,IJavaProject jproject) {
		this.jproject=jproject;
		this.pfs=pfs;
		this.icus=icus;
		this.types=types;
		shell=PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActivePart().getSite().getShell();
	}
	
	public void run() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/misplaceclass", "root", "123456");
			PreparedStatement ps=conn.prepareStatement("insert into relations values(?,?,?)");
			ps.setString(1, jproject.getElementName());
			
			
			run = Runtime.getRuntime();
			Random r=new Random();
			int total=0;
			for(int i=0;i<icus.size();i++){
				
				try {
					new ASTReader(jproject, null);
				} catch (CompilationErrorDetectedException e) {
					// TODO Auto-generated catch block
					System.out.println("Break Point:"+i);
					break;
				}
				
				
				
				

				long start=System.currentTimeMillis();
				ICompilationUnit icu=icus.get(i);
				ps.setString(2, types.get(i).getFullyQualifiedName());
				
				IPackageFragment pf=pfs.get(r.nextInt(pfs.size()));
				if(haveSameNameType(pf,icu.getElementName())) continue;
				
				IPackageFragment oripf=(IPackageFragment)(icu.getParent());
				System.out.println(pf.getElementName()+"  "+icu.getElementName()+"   Moving...");
				if(moveclass(pf,icu)) {
//					try {
//						new ASTReader(jproject, null);
//					} catch (CompilationErrorDetectedException e) {
//						// TODO Auto-generated catch block
//
//						undo.undo();
//						continue;
//					}
					
//					System.out.println(pf.getElementName()+"  "+icu.getElementName()+"   Moved!");
//					for(ICompilationUnit movedicu : pf.getCompilationUnits()) if(movedicu.getElementName().equals(icu.getElementName())) {
//						moveclass(oripf,movedicu);
//						System.out.println(oripf.getElementName()+"  "+movedicu.getElementName()+"  Back");
//						break;
//					}
					//undo.undo();
					ps.setString(3, pf.getElementName());
					ps.execute();
					total++;
				}



				long end=System.currentTimeMillis();
				System.out.println(""+(i+1)+" / "+icus.size()+"  already "+total+"  Time : "+(end-start)/1000);
				//System.out.println(icu.getParent().getElementName()+icu.getElementName());
				if(i%20==0)
					run.gc();
				
			}
			System.out.println(total);
			
			ps.close();
			conn.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	public boolean moveclass(IPackageFragment pf,ICompilationUnit clazz) throws InterruptedException, CoreException {

		IMovePolicy policy= ReorgPolicyFactory.createMovePolicy(new IResource[0],new IJavaElement[]{clazz});
		if (policy.canEnable()) {
			JavaMoveProcessor processor=new JavaMoveProcessor(policy);
			IReorgDestination destination=ReorgDestinationFactory.createDestination(pf);
			RefactoringStatus status=processor.setDestination(destination);
			if (status.hasError()) {
				return false;
			}
			processor.setUpdateReferences(true);
			//processor.setCreateTargetQueries(new CreateTargetQueries(shell));
			processor.setReorgQueries(new ReorgQueries(shell));
			ReorgQueries rq=new ReorgQueries(shell);
			MoveRefactoring refactoring = new MoveRefactoring(processor);
			IProgressMonitor pm = new NullProgressMonitor();
			
			try {
				refactoring.checkInitialConditions(pm);
				refactoring.checkFinalConditions(pm);
				final PerformRefactoringOperation op = new PerformRefactoringOperation(refactoring, CheckConditionsOperation.ALL_CONDITIONS);
				
				if(op.getConditionStatus().hasError())
					return false;
				if(op.getValidationStatus().hasError())
					return false;
//				op.run(new NullProgressMonitor());
//
//				try {
//					new ASTReader(jproject, null);
//				}catch(CompilationErrorDetectedException e) {
//					System.out.println("CompilationErrorDetectedException");
//					op.getUndoChange().perform(new NullProgressMonitor());
//					return false;
//				}
//
//				op.getUndoChange().perform(new NullProgressMonitor());

				return true;
				//op.run(new NullProgressMonitor());
				
				
			}catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
//				System.out.println("Error!!!");
//				if(op.getUndoChange()!=null) {
//					System.out.println("Error!!!");
//					op.getUndoChange().perform(new NullProgressMonitor());
//				}
				return false;
			}
		}
		return false;
	}
	
	public boolean haveSameNameType(IPackageFragment pf,String name) throws JavaModelException {
		for(ICompilationUnit icu : pf.getCompilationUnits()) if(icu.getElementName().equals(name))
			return true;
		return false;
	}
	
}
