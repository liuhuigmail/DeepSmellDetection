package gr.uom.java.ast;

public enum CommentType {
	BLOCK, LINE, JAVADOC;
}
