package gr.uom.java.jdeodorant.refactoring.mytest.buttons;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.internal.ui.packageview.PackageFragmentRootContainer;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.ISelectionService;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.progress.IProgressService;

import gr.uom.java.ast.ASTReader;
import gr.uom.java.ast.CompilationErrorDetectedException;
import gr.uom.java.ast.Standalone;
import gr.uom.java.distance.MoveMethodCandidateRefactoring;
import gr.uom.java.jdeodorant.refactoring.mytest.actions.MyProjectEvolution;

public class ActionsOfButtons implements IWorkbenchWindowActionDelegate {
	private static final String MESSAGE_DIALOG_TITLE = "Feature Envy";
	
	@SuppressWarnings("static-access")
	public void run(IAction action) {
		// TODO Auto-generated method stub
		IJavaProject selectedProject = JavaCore.create(getProject());
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		IProject selectedIProject = null;
		final Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
		if(selectedProject == null){
			Display.getDefault().asyncExec(new Runnable() {
	            public void run() {
	            	 MessageBox dialog=new MessageBox(shell,SWT.OK|SWT.ICON_INFORMATION);
	 		        dialog.setText("Warning");
	 		        dialog.setMessage("Please select a JavaProject to Compare!");
	 		        dialog.open();
	 		        return;
	            }
		 });
		}
		else{
			//System.out.println("Project   "+selectedProject.getElementName());
			for (IProject iProject : root.getProjects()) {
				if(iProject.getName().equals((selectedProject.getElementName()))){
					selectedIProject = iProject;
					break;
				}	
			 }		
			System.out.println("IProject's  name----"+selectedIProject.getName());
			
			MyProjectEvolution projectEvolution = new MyProjectEvolution(selectedProject, selectedIProject);
			try {
				projectEvolution.run();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
		public IProject getProject(){  
			IProject project = null;  
		//	IEditorPart part = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();  
			
			ISelectionService selectionService = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getSelectionService();    
			ISelection selection = selectionService.getSelection();    
			if(selection instanceof IStructuredSelection) {    
				Object element = ((IStructuredSelection)selection).getFirstElement();    
				
				if (element instanceof IResource) {    
					project= ((IResource)element).getProject();    
				} else if (element instanceof PackageFragmentRootContainer) {    
					IJavaProject jProject =     
							((PackageFragmentRootContainer)element).getJavaProject();    
					project = jProject.getProject();    
				} else if (element instanceof IJavaElement) {    
					IJavaProject jProject= ((IJavaElement)element).getJavaProject();    
					project = jProject.getProject();    
				}  
			}     
			
			return project;  
		} 


	public void selectionChanged(IAction arg0, ISelection arg1) {
		// TODO Auto-generated method stub

	}

	public void dispose() {
		// TODO Auto-generated method stub

	}

	public void init(IWorkbenchWindow arg0) {
		// TODO Auto-generated method stub

	}

}
