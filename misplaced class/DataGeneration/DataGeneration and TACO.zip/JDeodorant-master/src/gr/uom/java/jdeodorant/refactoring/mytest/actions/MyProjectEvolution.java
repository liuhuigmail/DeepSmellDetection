package gr.uom.java.jdeodorant.refactoring.mytest.actions;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.sql.*;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IField;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.progress.IProgressService;

import gr.uom.java.ast.ASTReader;
import gr.uom.java.ast.ClassObject;
import gr.uom.java.ast.CompilationErrorDetectedException;
import gr.uom.java.ast.Standalone;
import gr.uom.java.ast.SystemObject;
import gr.uom.java.distance.DistanceCalculator;
import gr.uom.java.distance.DistanceMatrix;
import gr.uom.java.distance.MoveMethodCandidateRefactoring;
import gr.uom.java.distance.MyClass;
import gr.uom.java.distance.MyMethod;
import gr.uom.java.distance.MySystem;
import gr.uom.java.jdeodorant.refactoring.mytest.actions.movemethod.MethodEntity;
import gr.uom.java.jdeodorant.refactoring.mytest.actions.movemethod.RelatedClass;


public class MyProjectEvolution {
	
	protected IJavaProject iJavaproject = null;
	protected IProject iProject = null;

	
	public HashMap<String,MyClass> cmap;
	public HashMap<String,HashSet<MyClass> > pmap;
	
	ArrayList<MyClass> classes;
	
	public MyProjectEvolution(IJavaProject selectedProject, IProject selectedIProject){
		this.iJavaproject = selectedProject;
		this.iProject = selectedIProject;
		cmap=new HashMap<String,MyClass>();
		pmap=new HashMap<String,HashSet<MyClass> >();
		classes=new ArrayList<MyClass>();
		
	}

	public void run() throws Exception{
		
		getAllCompilationUnits();
		
		//用于计算条件
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
	        Connection conn = DriverManager.getConnection(
	                "jdbc:mysql://127.0.0.1:3306/misplaceclass?serverTimezone=GMT",
	                "root","123456");
	        PreparedStatement ps=conn.prepareStatement("insert into intersection values(?,?,?)");
	        int ith=1;
	        for (IPackageFragment pf : iJavaproject.getPackageFragments()) {
	        	if(pf.getCompilationUnits().length==0) continue;
	        	

	        	System.out.println((ith++)+" / "+pmap.size());
	        	
				HashSet<MyClass> temp=pmap.get(pf.getElementName());

				if(temp==null) continue;
				for(MyClass mc : classes) {
					HashSet<String> pset=new HashSet<String>();
					Iterator<MyClass> ite=temp.iterator();
					
					while(ite.hasNext()) {
						MyClass e=ite.next();
						if(e.getName().equals(mc.getName())) continue;
						for(MyMethod method : e.getMethodList()) {
							pset.addAll(method.getEntitySet());
						}
					}
					HashSet<String> cset=new HashSet<String>();
					for(MyMethod method : mc.getMethodList()) {
						cset.addAll(method.getEntitySet());
					}
					
					
					int inter=DistanceCalculator.intersection(cset,pset).size();

					if(inter==0) continue;

					ps.setString(1, mc.getName());
					ps.setString(2, pf.getElementName());
					ps.setInt(3, inter);
					ps.execute();
				}
			}
	        ps.close();
	        conn.close();
	        System.out.println("Done");
	        
		}catch(Exception e) {
			e.printStackTrace();
		}
		
//		System.out.println("start");
//		try {
//			for(MyClass mc : classes) {
//				
//				
//				String key=mc.getName();
//				for (IPackageFragment pf : iJavaproject.getPackageFragments()) {
//					HashSet<String> pset=pmap.get(pf.getElementName());
//					Iterator<String> ite=pset.iterator();
//					int cnt=0;
//					while(ite.hasNext()) {
//						if(ite.next().contains(key)) {
//							//System.out.println(key+"   "+pf.getElementName());
//							cnt++;
//							break;
//						}
//					}
//					if(cnt>1) {
//						System.out.println("OK");
//					}
//				}
//			}
//			System.out.println("end");
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
		
	}

	protected List<ICompilationUnit> getAllCompilationUnits() {
		
		try {
			
			new ASTReader(iJavaproject, null);
			
			IWorkbench wb = PlatformUI.getWorkbench();
			IProgressService ps = wb.getProgressService();
	
			SystemObject systemObject = ASTReader.getSystemObject();
			if(systemObject != null) {
			
				Set<ClassObject> classObjectsToBeExamined = new LinkedHashSet<ClassObject>();
				
				classObjectsToBeExamined.addAll(systemObject.getClassObjects());
				//&&(classObject.getName().equals(methodNameAndItsTargetName.get(method))||(classObject.getName().equals(method.getDeclaringType().getFullyQualifiedName())))
				final Set<String> classNamesToBeExamined = new LinkedHashSet<String>();
				for(ClassObject classObject : classObjectsToBeExamined) {
					if(!classObject.isEnum() && !classObject.isInterface() && !classObject.isGeneratedByParserGenenator())
						classNamesToBeExamined.add(classObject.getName());
				}
				MySystem system = new MySystem(systemObject, false);
				

				for (IPackageFragment pf : iJavaproject.getPackageFragments()) {
					HashSet<MyClass> pset=new HashSet<MyClass>();
					for(ICompilationUnit icu : pf.getCompilationUnits()) {
						for(IType type : icu.getTypes()) if(icu.getElementName().equals(type.getElementName()+".java")) {
							MyClass mc=system.getClass(type.getFullyQualifiedName());
							if(mc==null) break;
							pset.add(mc);
							cmap.put(type.getFullyQualifiedName(), mc);
							classes.add(mc);
						}
					}
					if(pset.size()>0)
						pmap.put(pf.getElementName(), pset);
					
				}
	        }

		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		List<ICompilationUnit> allCompilationUnits = new ArrayList<ICompilationUnit>();
		
		return allCompilationUnits;
	}
}

